# 🏭 Warehouse Analytics Pro

A beautiful and professional GUI application for analyzing warehouse data, converted from the original command-line QTY.py tool.

## ✨ Features

### 📊 **Dashboard**
- Real-time statistics cards with key metrics
- Interactive charts showing priority distribution and stock status
- Professional color-coded visual indicators

### 📦 **Shelves Management**
- Detailed shelf analysis with hub counts
- Stock status breakdown (with stock, zero quantity, empty)
- Double-click to view detailed hub information

### 📍 **Location Analytics**
- Search and filter functionality
- Top 1000 locations display
- Stock status indicators for each location

### 🎯 **Priority Analysis**
- Priority-based hub categorization
- Detailed breakdown by stock status
- Interactive drill-down capabilities

### 🏭 **Warehouse Management**
- Warehouse selection dropdown
- Product listing by warehouse
- Detailed product information with quantities

### 📦 **Product Catalog**
- Comprehensive product search
- Multi-column display (SKU, name, warehouse, quantity, hub, priority, shelf)
- Real-time filtering

### 🗑️ **Scrap Analysis**
- Scrap hub identification
- Priority-based scrap grouping
- Detailed scrap reporting

### 🔧 **Additional Features**
- **Data Loading**: Support for JSON data files
- **Export Reports**: Generate detailed text reports
- **Professional UI**: Modern, clean interface with intuitive navigation
- **Responsive Design**: Scrollable tables and adaptive layouts
- **Status Bar**: Real-time progress and status updates

## 🚀 Installation

1. **Install Python Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Run the Application:**
   - **Windows**: Double-click `run_app.bat`
   - **Or run directly**: `python warehouse_analyzer_gui.py`

## 📋 Requirements

- Python 3.7+
- matplotlib (for charts)
- pandas (for data processing)
- tkinter (usually included with Python)

## 🎯 Usage

1. **Load Data**: Click "📁 Load Data" to select your JSON file
2. **Navigate Tabs**: Use the tabbed interface to explore different aspects
3. **Search & Filter**: Use search boxes to find specific items
4. **Export Reports**: Click "📊 Export Report" to save analysis results
5. **Detailed Views**: Double-click rows to see detailed information

## 📊 Data Format

The application expects JSON data with the following structure:
```json
[
  {
    "name": "Hub Name",
    "shelf": 1,
    "priority": 1,
    "is_locked": false,
    "is_scrap": 0,
    "is_pallet": 0,
    "in_stock": [
      {
        "sku": "SKU123",
        "name": "Product Name",
        "warehouse_name": "Warehouse Name",
        "quantity": 10
      }
    ]
  }
]
```

## 🎨 Interface Features

- **Professional Color Scheme**: Modern, business-appropriate colors
- **Intuitive Navigation**: Tabbed interface for easy access to all features
- **Interactive Charts**: Visual data representation with matplotlib
- **Responsive Tables**: Scrollable, sortable data displays
- **Search Functionality**: Real-time filtering across multiple tabs
- **Export Capabilities**: Generate comprehensive reports

## 🔍 Key Improvements from Original

- ✅ **GUI Interface**: Replaced command-line with modern GUI
- ✅ **Visual Charts**: Added data visualization
- ✅ **Professional Design**: Clean, business-ready interface
- ✅ **Enhanced Navigation**: Tabbed interface for better organization
- ✅ **Search & Filter**: Real-time data filtering
- ✅ **Export Reports**: Professional report generation
- ✅ **Status Indicators**: Color-coded information display
- ✅ **Interactive Elements**: Double-click for detailed views

## 📞 Support

For issues or questions, please refer to the original QTY.py functionality as this GUI maintains all the original analytical capabilities while adding a professional interface.
