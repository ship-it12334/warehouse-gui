#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json
from collections import Counter, defaultdict
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import pandas as pd
from datetime import datetime
import os

class WarehouseAnalyzerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("🏭 Warehouse Analytics")
        self.root.geometry("1400x900")
        
        # Professional color scheme
        self.colors = {
            'primary': '#2c3e50',
            'secondary': '#3498db',
            'success': '#27ae60',
            'warning': '#f39c12',
            'danger': '#e74c3c',
            'light': '#ecf0f1',
            'dark': '#34495e',
            'accent': '#9b59b6'
        }
        
        # Configure styles
        self.setup_styles()
        
        # Data storage
        self.data = None
        self.hubs = []
        self.stats = {}
        
        # Sorting state for treeviews
        self.sort_states = {
            'shelves': {'column': None, 'reverse': False},
            'locations': {'column': None, 'reverse': False},
            'warehouse_products': {'column': None, 'reverse': False},
            'products': {'column': None, 'reverse': False},
            'expiry': {'column': None, 'reverse': False}
        }
        
        # Create main interface
        self.create_widgets()
        
        # Auto-load default file if exists
        if os.path.exists('hub_1_positions_full.json'):
            self.load_data('hub_1_positions_full.json')
    
    def setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        
        # Configure custom styles
        style.configure('Title.TLabel', font=('Arial', 20, 'bold'), 
                       background=self.colors['primary'], foreground='white')
        style.configure('Header.TLabel', font=('Arial', 12, 'bold'),
                       background=self.colors['light'])
        style.configure('Stats.TLabel', font=('Arial', 12))
        style.configure('Action.TButton', font=('Arial', 10, 'bold'))
        
    def create_widgets(self):
        # Main container
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Header
        self.create_header(main_frame)
        
        # Content area with notebook
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True, pady=(10, 0))
        
        # Create tabs
        self.create_dashboard_tab()
        self.create_dashboard_charts_tab()
        self.create_shelves_tab()
        self.create_locations_tab()
        self.create_priority_tab()
        self.create_warehouses_tab()
        self.create_products_tab()
        self.create_scrap_tab()
        self.create_pallet_tab()
        self.create_multi_warehouse_tab()
        self.create_locked_tab()
        self.create_missing_data_tab()
        self.create_expiry_tab()
        self.create_duplicates_tab()
        
        # Status bar
        self.create_status_bar(main_frame)
    
    def create_header(self, parent):
        header_frame = ttk.Frame(parent)
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Title
        title_label = ttk.Label(header_frame, text="🏭 Warehouse Analytics Pro", 
                               style='Title.TLabel')
        title_label.pack(fill=tk.X)
        
        # Control panel
        control_frame = ttk.Frame(header_frame)
        control_frame.pack(fill=tk.X, pady=5)
        
        ttk.Button(control_frame, text="📁 Load Data", 
                  command=self.load_data_file, style='Action.TButton').pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="🔄 Refresh", 
                  command=self.refresh_data, style='Action.TButton').pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="📊 Export Report", 
                  command=self.export_report, style='Action.TButton').pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="📈 Export Excel", 
                  command=self.export_all_to_excel, style='Action.TButton').pack(side=tk.LEFT, padx=5)
        
        # Data info label
        self.data_info_label = ttk.Label(control_frame, text="No data loaded", 
                                        style='Stats.TLabel')
        self.data_info_label.pack(side=tk.RIGHT, padx=10)
    
    def create_dashboard_tab(self):
        dashboard_frame = ttk.Frame(self.notebook)
        self.notebook.add(dashboard_frame, text="📊 Dashboard")
        
        # Create scrollable frame
        canvas = tk.Canvas(dashboard_frame)
        scrollbar = ttk.Scrollbar(dashboard_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Stats cards with full width expansion
        self.stats_cards_frame = ttk.Frame(scrollable_frame)
        self.stats_cards_frame.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
    
    def create_dashboard_charts_tab(self):
        charts_frame = ttk.Frame(self.notebook)
        self.notebook.add(charts_frame, text="📈 Dashboard Charts")
        
        # Create scrollable frame for charts with both vertical and horizontal scrolling
        canvas = tk.Canvas(charts_frame)
        v_scrollbar = ttk.Scrollbar(charts_frame, orient="vertical", command=canvas.yview)
        h_scrollbar = ttk.Scrollbar(charts_frame, orient="horizontal", command=canvas.xview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        
        # Charts frame in this tab
        self.dashboard_charts_frame = ttk.Frame(scrollable_frame)
        self.dashboard_charts_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Pack scrollbars and canvas
        h_scrollbar.pack(side="bottom", fill="x")
        v_scrollbar.pack(side="right", fill="y")
        canvas.pack(side="top", fill="both", expand=True)
    
    def create_shelves_tab(self):
        shelves_frame = ttk.Frame(self.notebook)
        self.notebook.add(shelves_frame, text="📦 Shelves")
        
        # Treeview for shelves
        self.create_shelves_treeview(shelves_frame)
    
    def create_locations_tab(self):
        locations_frame = ttk.Frame(self.notebook)
        self.notebook.add(locations_frame, text="📍 Locations")
        
        # Search and filter
        search_frame = ttk.Frame(locations_frame)
        search_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Label(search_frame, text="Search:").pack(side=tk.LEFT, padx=5)
        self.location_search = ttk.Entry(search_frame, width=30)
        self.location_search.pack(side=tk.LEFT, padx=5)
        self.location_search.bind('<KeyRelease>', self.filter_locations)
        
        # Create a container frame for the treeview using grid
        tree_container = ttk.Frame(locations_frame)
        tree_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Treeview for locations
        self.create_locations_treeview(tree_container)
    
    def create_priority_tab(self):
        priority_frame = ttk.Frame(self.notebook)
        self.notebook.add(priority_frame, text="🎯 Priority")
        
        # Priority analysis frame
        self.priority_frame = ttk.Frame(priority_frame)
        self.priority_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    def create_warehouses_tab(self):
        warehouses_frame = ttk.Frame(self.notebook)
        self.notebook.add(warehouses_frame, text="🏭 Warehouses")
        
        # Warehouse selector
        selector_frame = ttk.Frame(warehouses_frame)
        selector_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Label(selector_frame, text="Select Warehouse:").pack(side=tk.LEFT, padx=5)
        self.warehouse_var = tk.StringVar()
        self.warehouse_combo = ttk.Combobox(selector_frame, textvariable=self.warehouse_var, 
                                           state="readonly", width=30)
        self.warehouse_combo.pack(side=tk.LEFT, padx=5)
        self.warehouse_combo.bind('<<ComboboxSelected>>', self.show_warehouse_details)
        
        # Search frame
        search_frame = ttk.Frame(warehouses_frame)
        search_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Label(search_frame, text="Search Products:").pack(side=tk.LEFT, padx=5)
        self.warehouse_search = ttk.Entry(search_frame, width=30)
        self.warehouse_search.pack(side=tk.LEFT, padx=5)
        self.warehouse_search.bind('<KeyRelease>', self.filter_warehouse_products)
        
        # Export and copy buttons
        button_frame = ttk.Frame(warehouses_frame)
        button_frame.pack(fill=tk.X, padx=10, pady=5)
        ttk.Button(button_frame, text="📈 Export to Excel", 
                  command=lambda: self.export_treeview_to_excel(self.warehouse_products_tree, 'warehouse_products')).pack(side=tk.RIGHT, padx=2)
        ttk.Button(button_frame, text="📋 Copy Table", 
                  command=lambda: self.copy_treeview_to_clipboard(self.warehouse_products_tree)).pack(side=tk.RIGHT, padx=2)
        
        # Create a container frame for the treeview
        tree_container = ttk.Frame(warehouses_frame)
        tree_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Products treeview
        self.create_warehouse_products_treeview(tree_container)
    
    def create_products_tab(self):
        products_frame = ttk.Frame(self.notebook)
        self.notebook.add(products_frame, text="📦 Products")
        
        # Product search
        search_frame = ttk.Frame(products_frame)
        search_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Label(search_frame, text="Search Products:").pack(side=tk.LEFT, padx=5)
        self.product_search = ttk.Entry(search_frame, width=30)
        self.product_search.pack(side=tk.LEFT, padx=5)
        self.product_search.bind('<KeyRelease>', self.filter_products)
        
        # Export and copy buttons
        button_frame = ttk.Frame(products_frame)
        button_frame.pack(fill=tk.X, padx=10, pady=5)
        ttk.Button(button_frame, text="📈 Export to Excel", 
                  command=lambda: self.export_treeview_to_excel(self.products_tree, 'products')).pack(side=tk.RIGHT, padx=2)
        ttk.Button(button_frame, text="📋 Copy Table", 
                  command=lambda: self.copy_treeview_to_clipboard(self.products_tree)).pack(side=tk.RIGHT, padx=2)
        
        # Create a container frame for the treeview
        tree_container = ttk.Frame(products_frame)
        tree_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Products treeview
        self.create_products_treeview(tree_container)
    
    def create_scrap_tab(self):
        scrap_frame = ttk.Frame(self.notebook)
        self.notebook.add(scrap_frame, text="🗑️ Scrap")
        
        # Scrap analysis frame
        self.scrap_frame = ttk.Frame(scrap_frame)
        self.scrap_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    def create_pallet_tab(self):
        pallet_frame = ttk.Frame(self.notebook)
        self.notebook.add(pallet_frame, text="📦 Pallet")
        
        # Pallet analysis frame
        self.pallet_frame = ttk.Frame(pallet_frame)
        self.pallet_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    def create_multi_warehouse_tab(self):
        multi_warehouse_frame = ttk.Frame(self.notebook)
        self.notebook.add(multi_warehouse_frame, text="🔄 Multi-Warehouse")
        
        # Multi-warehouse analysis frame
        self.multi_warehouse_frame = ttk.Frame(multi_warehouse_frame)
        self.multi_warehouse_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    def create_locked_tab(self):
        locked_frame = ttk.Frame(self.notebook)
        self.notebook.add(locked_frame, text="🔒 Locked")
        
        # Locked analysis frame
        self.locked_frame = ttk.Frame(locked_frame)
        self.locked_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    def create_missing_data_tab(self):
        missing_frame = ttk.Frame(self.notebook)
        self.notebook.add(missing_frame, text="❓ Missing Data")
        
        # Missing data analysis frame
        self.missing_frame = ttk.Frame(missing_frame)
        self.missing_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    def create_expiry_tab(self):
        expiry_frame = ttk.Frame(self.notebook)
        self.notebook.add(expiry_frame, text="📅 Expiry Dates")
        
        # Expiry analysis frame
        self.expiry_frame = ttk.Frame(expiry_frame)
        self.expiry_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    def create_duplicates_tab(self):
        duplicates_frame = ttk.Frame(self.notebook)
        self.notebook.add(duplicates_frame, text="🔄 Duplicates")
        
        # Duplicates analysis frame
        self.duplicates_frame = ttk.Frame(duplicates_frame)
        self.duplicates_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    
    def create_shelves_treeview(self, parent):
        # Treeview
        columns = ('Shelf', 'Total Hubs', 'With Stock', 'Zero Qty', 'Empty')
        self.shelves_tree = ttk.Treeview(parent, columns=columns, show='headings', height=20)
        
        for col in columns:
            self.shelves_tree.heading(col, text=col, command=lambda c=col: self.sort_treeview('shelves', c))
            self.shelves_tree.column(col, width=120)
        
        # Export and copy buttons
        export_frame = ttk.Frame(parent)
        export_frame.grid(row=2, column=0, columnspan=2, sticky='ew', padx=10, pady=5)
        ttk.Button(export_frame, text="📈 Export to Excel", 
                  command=lambda: self.export_treeview_to_excel(self.shelves_tree, 'shelves')).pack(side=tk.RIGHT, padx=2)
        ttk.Button(export_frame, text="📋 Copy Table", 
                  command=lambda: self.copy_treeview_to_clipboard(self.shelves_tree)).pack(side=tk.RIGHT, padx=2)
        
        # Scrollbars
        vsb = ttk.Scrollbar(parent, orient="vertical", command=self.shelves_tree.yview)
        hsb = ttk.Scrollbar(parent, orient="horizontal", command=self.shelves_tree.xview)
        self.shelves_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        self.shelves_tree.grid(row=0, column=0, sticky='nsew', padx=10, pady=10)
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')
        
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)
        
        # Bind double-click
        self.shelves_tree.bind('<Double-1>', self.show_shelf_details)
    
    def create_locations_treeview(self, parent):
        # Treeview
        columns = ('Location', 'Total Hubs', 'With Stock', 'Zero Qty')
        self.locations_tree = ttk.Treeview(parent, columns=columns, show='headings', height=20)
        
        for col in columns:
            self.locations_tree.heading(col, text=col, command=lambda c=col: self.sort_treeview('locations', c))
            self.locations_tree.column(col, width=150)
        
        # Export and copy buttons
        export_frame = ttk.Frame(parent)
        export_frame.grid(row=2, column=0, columnspan=2, sticky='ew', padx=10, pady=5)
        ttk.Button(export_frame, text="📈 Export to Excel", 
                  command=lambda: self.export_treeview_to_excel(self.locations_tree, 'locations')).pack(side=tk.RIGHT, padx=2)
        ttk.Button(export_frame, text="📋 Copy Table", 
                  command=lambda: self.copy_treeview_to_clipboard(self.locations_tree)).pack(side=tk.RIGHT, padx=2)
        
        # Scrollbars
        vsb = ttk.Scrollbar(parent, orient="vertical", command=self.locations_tree.yview)
        hsb = ttk.Scrollbar(parent, orient="horizontal", command=self.locations_tree.xview)
        self.locations_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        self.locations_tree.grid(row=0, column=0, sticky='nsew', padx=10, pady=10)
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')
        
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)
    
    def create_warehouse_products_treeview(self, parent):
        # Treeview
        columns = ('SKU', 'Product Name', 'Quantity', 'Hub Name')
        self.warehouse_products_tree = ttk.Treeview(parent, columns=columns, 
                                                   show='headings', height=20)
        
        for col in columns:
            self.warehouse_products_tree.heading(col, text=col, command=lambda c=col: self.sort_treeview('warehouse_products', c))
            self.warehouse_products_tree.column(col, width=150)
        
        # Export and copy buttons
        export_frame = ttk.Frame(parent)
        export_frame.grid(row=2, column=0, columnspan=2, sticky='ew', padx=10, pady=5)
        ttk.Button(export_frame, text="📈 Export to Excel", 
                  command=lambda: self.export_treeview_to_excel(self.warehouse_products_tree, 'warehouse_products')).pack(side=tk.RIGHT, padx=2)
        ttk.Button(export_frame, text="📋 Copy Table", 
                  command=lambda: self.copy_treeview_to_clipboard(self.warehouse_products_tree)).pack(side=tk.RIGHT, padx=2)
        
        # Scrollbars
        vsb = ttk.Scrollbar(parent, orient="vertical", command=self.warehouse_products_tree.yview)
        hsb = ttk.Scrollbar(parent, orient="horizontal", command=self.warehouse_products_tree.xview)
        self.warehouse_products_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        self.warehouse_products_tree.grid(row=0, column=0, sticky='nsew', padx=10, pady=10)
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')
        
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)
    
    def create_products_treeview(self, parent):
        # Treeview
        columns = ('SKU', 'Product Name', 'Warehouse', 'Quantity', 'Hub Name', 'Priority', 'Shelf')
        self.products_tree = ttk.Treeview(parent, columns=columns, show='headings', height=20)
        
        for col in columns:
            self.products_tree.heading(col, text=col, command=lambda c=col: self.sort_treeview('products', c))
            self.products_tree.column(col, width=120)
        
        # Export and copy buttons
        export_frame = ttk.Frame(parent)
        export_frame.grid(row=2, column=0, columnspan=2, sticky='ew', padx=10, pady=5)
        ttk.Button(export_frame, text="📈 Export to Excel", 
                  command=lambda: self.export_treeview_to_excel(self.products_tree, 'products')).pack(side=tk.RIGHT, padx=2)
        ttk.Button(export_frame, text="📋 Copy Table", 
                  command=lambda: self.copy_treeview_to_clipboard(self.products_tree)).pack(side=tk.RIGHT, padx=2)
        
        # Scrollbars
        vsb = ttk.Scrollbar(parent, orient="vertical", command=self.products_tree.yview)
        hsb = ttk.Scrollbar(parent, orient="horizontal", command=self.products_tree.xview)
        self.products_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        self.products_tree.grid(row=0, column=0, sticky='nsew', padx=10, pady=10)
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')
        
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)
    
    def create_status_bar(self, parent):
        status_frame = ttk.Frame(parent)
        status_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.status_label = ttk.Label(status_frame, text="Ready", relief=tk.SUNKEN)
        self.status_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        # Progress bar
        self.progress = ttk.Progressbar(status_frame, mode='indeterminate')
        self.progress.pack(side=tk.RIGHT, padx=5)
    
    def load_data_file(self):
        filename = filedialog.askopenfilename(
            title="Select JSON file",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        if filename:
            self.load_data(filename)
    
    def load_data(self, filename):
        try:
            self.progress.start()
            self.status_label.config(text=f"Loading {filename}...")
            
            with open(filename, 'r', encoding='utf-8') as f:
                self.data = json.load(f)
            
            self.hubs = self.data if isinstance(self.data, list) else self.data.get('hubs', [])
            
            # Calculate statistics
            self.calculate_stats()
            
            # Update UI
            self.update_dashboard()
            self.update_all_tabs()
            
            self.data_info_label.config(text=f"✅ {len(self.hubs)} hubs loaded")
            self.status_label.config(text="Data loaded successfully")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load data: {str(e)}")
            self.status_label.config(text="Load failed")
        finally:
            self.progress.stop()
    
    def calculate_warehouse_stats(self):
        """Calculate detailed warehouse statistics for charts"""
        warehouse_stats = {}
        
        for hub in self.hubs:
            products = hub.get('in_stock', [])
            for product in products:
                warehouse = product.get('warehouse_name', 'Unknown')
                quantity = product.get('quantity', 0)
                
                if warehouse not in warehouse_stats:
                    warehouse_stats[warehouse] = {
                        'total_quantity': 0,
                        'empty_hubs': 0,
                        'zero_qty_hubs': 0,
                        'with_stock_hubs': 0,
                        'product_count': 0
                    }
                
                warehouse_stats[warehouse]['total_quantity'] += quantity
                warehouse_stats[warehouse]['product_count'] += 1
                
                # Classify hub status
                if not products:
                    warehouse_stats[warehouse]['empty_hubs'] += 1
                elif all(p.get('quantity', 0) == 0 for p in products):
                    warehouse_stats[warehouse]['zero_qty_hubs'] += 1
                else:
                    warehouse_stats[warehouse]['with_stock_hubs'] += 1
        
        return warehouse_stats

    def calculate_stats(self):
        # Reset stats
        self.stats = {
            'shelf': Counter(),
            'priority': Counter(),
            'status': {'locked': 0, 'scrap': 0, 'pallet': 0},
            'stock': {'empty': [], 'stock': [], 'zero': []},
            'warehouse': Counter(),
            'locations': Counter()
        }
        
        for hub in self.hubs:
            # Shelf
            shelf = hub.get('shelf')
            if shelf is not None:
                self.stats['shelf'][shelf] += 1
            
            # Priority
            priority = hub.get('priority')
            if priority is not None:
                self.stats['priority'][priority] += 1
            
            # Status
            self.stats['status']['locked'] += hub.get('is_locked', False)
            self.stats['status']['scrap'] += hub.get('is_scrap', 0)
            self.stats['status']['pallet'] += hub.get('is_pallet', 0)
            
            # Stock analysis
            products = hub.get('in_stock', [])
            quantities = [p.get('quantity', 0) for p in products]
            has_positive = any(q > 0 for q in quantities)
            all_zero = all(q == 0 for q in quantities)
            
            if not products:
                self.stats['stock']['empty'].append(hub)
            elif all_zero:
                self.stats['stock']['zero'].append(hub)
            else:
                self.stats['stock']['stock'].append(hub)
            
            # Warehouse counts
            for product in products:
                self.stats['warehouse'][product.get('warehouse_name', 'Unknown')] += 1
            
            # Location counts
            location = hub.get('name', 'Unknown')
            self.stats['locations'][location] += 1
    
    def update_dashboard(self):
        # Clear existing widgets
        for widget in self.stats_cards_frame.winfo_children():
            widget.destroy()
        for widget in self.dashboard_charts_frame.winfo_children():
            widget.destroy()
        
        # Create stats cards
        self.create_stats_cards()
        
        # Create charts in dashboard charts tab
        self.create_dashboard_charts()
    
    def create_stats_cards(self):
        # Main stats
        total_hubs = len(self.hubs)
        with_stock = len(self.stats['stock']['stock'])
        zero_qty = len(self.stats['stock']['zero'])
        empty = len(self.stats['stock']['empty'])
        warehouses = len(self.stats['warehouse'])
        
        # Calculate products per company
        warehouse_stats = self.calculate_warehouse_stats()
        total_products = sum(stats['product_count'] for stats in warehouse_stats.values())
        
        # Main stats cards frame
        cards_frame = ttk.Frame(self.stats_cards_frame)
        cards_frame.pack(fill=tk.BOTH, expand=True, pady=2)
        
        cards_data = [
            ("📦 Total Hubs", total_hubs, self.colors['primary']),
            ("✅ With Stock", with_stock, self.colors['success']),
            ("❌ Zero Qty", zero_qty, self.colors['warning']),
            ("⭕ Empty", empty, self.colors['danger']),
            ("🏭 Warehouses", warehouses, self.colors['secondary']),
            ("💯 Total Products", total_products, self.colors['accent']),
            ("🔒 Locked", self.stats['status']['locked'], self.colors['dark']),
            ("🗑️ Scrap", self.stats['status']['scrap'], self.colors['danger'])
        ]
        
        for i, (title, value, color) in enumerate(cards_data):
            card = self.create_stat_card(cards_frame, title, value, color)
            card.grid(row=i//4, column=i%4, padx=1, pady=1, sticky='nsew')
        
        # Configure grid columns for equal width and expansion
        for col in range(4):
            cards_frame.columnconfigure(col, weight=1, minsize=200)
        
        # Add company products breakdown below main cards
        company_frame = ttk.LabelFrame(self.stats_cards_frame, text="Products per Company (All)", padding=2)
        company_frame.pack(fill=tk.X, pady=2)
        
        # Show all companies by product count
        if warehouse_stats:
            sorted_companies = sorted(warehouse_stats.items(), 
                                    key=lambda x: x[1]['product_count'], reverse=True)
            
            # Create scrollable frame for many companies
            canvas = tk.Canvas(company_frame, height=150)
            scrollbar = ttk.Scrollbar(company_frame, orient="horizontal", command=canvas.xview)
            scrollable_frame = ttk.Frame(canvas)
            
            scrollable_frame.bind(
                "<Configure>",
                lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
            )
            
            canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
            canvas.configure(xscrollcommand=scrollbar.set)
            
            company_cards_frame = ttk.Frame(scrollable_frame)
            company_cards_frame.pack(fill=tk.X)
            
            # Create cards for all companies
            for i, (company, stats) in enumerate(sorted_companies):
                company_card = self.create_stat_card(company_cards_frame, 
                                                    company[:20] + "..." if len(company) > 20 else company, 
                                                    stats['product_count'], 
                                                    self.colors['secondary'])
                company_card.grid(row=0, column=i, padx=2, pady=2, sticky='ew')
            
            canvas.pack(side="top", fill="both", expand=True)
            scrollbar.pack(side="bottom", fill="x")
        
        # Add company quantity comparison section
        quantity_frame = ttk.LabelFrame(self.stats_cards_frame, text="Company Quantity Comparison (Zero vs >0)", padding=6)
        quantity_frame.pack(fill=tk.X, pady=6)
        
        # Show all companies with zero vs positive quantity comparison
        if warehouse_stats:
            # Calculate zero vs positive quantities for each company
            company_quantity_data = {}
            for hub in self.hubs:
                products = hub.get('in_stock', [])
                for product in products:
                    warehouse = product.get('warehouse_name', 'Unknown')
                    quantity = product.get('quantity', 0)
                    
                    if warehouse not in company_quantity_data:
                        company_quantity_data[warehouse] = {'zero_qty': 0, 'positive_qty': 0}
                    
                    if quantity == 0:
                        company_quantity_data[warehouse]['zero_qty'] += 1
                    else:
                        company_quantity_data[warehouse]['positive_qty'] += 1
            
            # Sort by total quantity (positive + zero)
            sorted_companies = sorted(company_quantity_data.items(), 
                                   key=lambda x: x[1]['positive_qty'] + x[1]['zero_qty'], reverse=True)
            
            # Create scrollable frame for company quantity comparison
            canvas2 = tk.Canvas(quantity_frame, height=150)
            scrollbar2 = ttk.Scrollbar(quantity_frame, orient="horizontal", command=canvas2.xview)
            scrollable_frame2 = ttk.Frame(canvas2)
            
            scrollable_frame2.bind(
                "<Configure>",
                lambda e: canvas2.configure(scrollregion=canvas2.bbox("all"))
            )
            
            canvas2.create_window((0, 0), window=scrollable_frame2, anchor="nw")
            canvas2.configure(xscrollcommand=scrollbar2.set)
            
            quantity_cards_frame = ttk.Frame(scrollable_frame2)
            quantity_cards_frame.pack(fill=tk.X)
            
            # Create comparison cards for all companies
            for i, (company, qty_data) in enumerate(sorted_companies):
                total = qty_data['positive_qty'] + qty_data['zero_qty']
                company_name = company[:18] + "..." if len(company) > 18 else company
                
                # Create a frame for each company with two sub-cards
                company_frame = ttk.Frame(quantity_cards_frame)
                company_frame.grid(row=0, column=i, padx=3, pady=3, sticky='ew')
                
                # Zero quantity card (red)
                zero_card = tk.Frame(company_frame, bg=self.colors['danger'], relief=tk.RAISED, bd=1)
                zero_card.pack(fill=tk.X, pady=1)
                zero_label = tk.Label(zero_card, text=f"0 Qty: {qty_data['zero_qty']}", 
                                   bg=self.colors['danger'], fg='white', font=('Arial', 9, 'bold'))
                zero_label.pack(padx=5, pady=2)
                
                # Positive quantity card (green)
                positive_card = tk.Frame(company_frame, bg=self.colors['success'], relief=tk.RAISED, bd=1)
                positive_card.pack(fill=tk.X, pady=1)
                positive_label = tk.Label(positive_card, text=f">0 Qty: {qty_data['positive_qty']}", 
                                       bg=self.colors['success'], fg='white', font=('Arial', 9, 'bold'))
                positive_label.pack(padx=5, pady=2)
                
                # Company name label
                name_label = tk.Label(company_frame, text=company_name, 
                                   font=('Arial', 8, 'bold'), fg=self.colors['dark'])
                name_label.pack(pady=1)
            
            canvas2.pack(side="top", fill="both", expand=True)
            scrollbar2.pack(side="bottom", fill="x")
        
        # Add expiry analysis section
        expiry_frame = ttk.LabelFrame(self.stats_cards_frame, text="Expiry Analysis", padding=10)
        expiry_frame.pack(fill=tk.X, pady=10)
        
        # Calculate expiry statistics
        today = datetime.now().strftime('%Y-%m-%d')
        expiring_products = []
        expired_with_stock = []
        duplicate_skus = []
        total_expiry_products = 0
        
        for hub in self.hubs:
            for product in hub.get('in_stock', []):
                expiry_date = product.get('expiry_date')
                quantity = product.get('quantity', 0)
                sku = product.get('sku', '')
                
                if expiry_date:
                    total_expiry_products += 1
                    # Compare dates (assuming YYYY-MM-DD format)
                    try:
                        if expiry_date < today:
                            expiring_products.append({
                                'hub_name': hub.get('name', 'Unknown'),
                                'sku': product.get('sku', 'N/A'),
                                'product_name': product.get('name', 'Unknown'),
                                'warehouse': product.get('warehouse_name', 'Unknown'),
                                'quantity': quantity,
                                'expiry_date': expiry_date
                            })
                            # Also track expired products that still have stock
                            if quantity > 0:
                                expired_with_stock.append({
                                    'hub_name': hub.get('name', 'Unknown'),
                                    'sku': product.get('sku', 'N/A'),
                                    'product_name': product.get('name', 'Unknown'),
                                    'warehouse': product.get('warehouse_name', 'Unknown'),
                                    'quantity': quantity,
                                    'expiry_date': expiry_date
                                })
                    except:
                        # Handle different date formats by trying to parse
                        pass
        
        # Find duplicate SKUs with quantity > 0
        sku_quantities = defaultdict(list)
        for hub in self.hubs:
            for product in hub.get('in_stock', []):
                sku = product.get('sku', '')
                quantity = product.get('quantity', 0)
                if sku and quantity > 0:
                    sku_quantities[sku].append(product)
        
        # Count duplicates
        for sku, products in sku_quantities.items():
            if len(products) > 1:
                total_qty = sum(p.get('quantity', 0) for p in products)
                duplicate_skus.append({
                    'sku': sku,
                    'duplicate_count': len(products),
                    'total_quantity': total_qty,
                    'locations': list(set(p.get('warehouse_name', '') for p in products))
                })
        
        # Find duplicate product names with quantity > 0
        product_name_quantities = defaultdict(list)
        for hub in self.hubs:
            for product in hub.get('in_stock', []):
                product_name = product.get('name', '')
                quantity = product.get('quantity', 0)
                if product_name and quantity > 0:
                    product_name_quantities[product_name].append(product)
        
        # Count duplicate product names
        duplicate_product_names = []
        for product_name, products in product_name_quantities.items():
            if len(products) > 1:
                total_qty = sum(p.get('quantity', 0) for p in products)
                duplicate_product_names.append({
                    'product_name': product_name,
                    'duplicate_count': len(products),
                    'total_quantity': total_qty,
                    'locations': list(set(p.get('warehouse_name', '') for p in products)),
                    'skus': list(set(p.get('sku', '') for p in products))
                })
        
        # Create expiry cards
        expiry_cards_frame = ttk.Frame(expiry_frame)
        expiry_cards_frame.pack(fill=tk.X)
        
        expiry_cards_data = [
            ("📅 Total with Expiry Dates", total_expiry_products, self.colors['warning']),
            ("⚠️ Expired Products", len(expiring_products), self.colors['danger']),
            ("🚨 Expired with Stock", len(expired_with_stock), self.colors['danger']),
            ("🔄 Duplicate SKUs", len(duplicate_skus), self.colors['warning']),
            ("📝 Duplicate Product Names", len(duplicate_product_names), self.colors['warning'])
        ]
        
        for i, (title, value, color) in enumerate(expiry_cards_data):
            card = self.create_stat_card(expiry_cards_frame, title, value, color)
            card.grid(row=0, column=i, padx=5, pady=5, sticky='ew')
        
        # Add show details buttons for expired products
        button_frame = ttk.Frame(expiry_frame)
        button_frame.pack(fill=tk.X, pady=5)
        
        # Create button rows for better organization
        button_row1 = ttk.Frame(button_frame)
        button_row1.pack(fill=tk.X, pady=2)
        
        button_row2 = ttk.Frame(button_frame)
        button_row2.pack(fill=tk.X, pady=2)
        
        if expiring_products:
            ttk.Button(button_row1, text="📋 Show Expired Products Details", 
                      command=lambda: self.show_expired_products_details(expiring_products)).pack(side=tk.LEFT, padx=5)
        
        if expired_with_stock:
            ttk.Button(button_row1, text="🚨 Show Expired with Stock Details", 
                      command=lambda: self.show_expired_products_details(expired_with_stock)).pack(side=tk.LEFT, padx=5)
        
        if duplicate_skus:
            ttk.Button(button_row2, text="🔄 Show Duplicate SKUs Details", 
                      command=lambda: self.show_duplicate_skus_details(duplicate_skus)).pack(side=tk.LEFT, padx=5)
        
        if duplicate_product_names:
            ttk.Button(button_row2, text="📝 Show Duplicate Product Names Details", 
                      command=lambda: self.show_duplicate_product_names_details(duplicate_product_names)).pack(side=tk.LEFT, padx=5)
        
        cards_frame.columnconfigure(0, weight=1)
        cards_frame.columnconfigure(1, weight=1)
        cards_frame.columnconfigure(2, weight=1)
        cards_frame.columnconfigure(3, weight=1)
        cards_frame.columnconfigure(4, weight=1)
        cards_frame.columnconfigure(3, weight=1)
    
    def create_stat_card(self, parent, title, value, color):
        frame = tk.Frame(parent, bg=color, relief=tk.RAISED, bd=1)
        
        title_label = tk.Label(frame, text=title, bg=color, fg='white', 
                              font=('Arial', 10, 'bold'), wraplength=120)
        title_label.pack(pady=2)
        
        value_label = tk.Label(frame, text=str(value), bg=color, fg='white', 
                              font=('Arial', 12, 'bold'))
        value_label.pack(pady=2)
        
        return frame
    
    def create_dashboard_charts(self):
        # Create figure with subplots (6x1 column layout with reasonable size)
        fig = Figure(figsize=(14, 20), dpi=100)
        
        # Priority distribution pie chart
        ax1 = fig.add_subplot(611)
        priorities = dict(self.stats['priority'])
        if priorities:
            colors = ['#ff9999', '#66b3ff', '#99ff99', '#ffcc99', '#ff99cc']
            wedges, texts, autotexts = ax1.pie(priorities.values(), 
                                               labels=[f"Priority {k}" for k in priorities.keys()], 
                                               autopct='%1.1f%%', startangle=90, colors=colors[:len(priorities)])
            ax1.set_title('Priority Distribution', fontweight='bold', fontsize=14)
        
        # Stock status bar chart
        ax2 = fig.add_subplot(612)
        stock_data = {
            'With Stock': len(self.stats['stock']['stock']),
            'Zero Qty': len(self.stats['stock']['zero']),
            'Empty': len(self.stats['stock']['empty'])
        }
        bars = ax2.bar(stock_data.keys(), stock_data.values(), 
                      color=[self.colors['success'], self.colors['warning'], self.colors['danger']])
        ax2.set_title('Stock Status', fontweight='bold', fontsize=14)
        ax2.set_ylabel('Number of Hubs', fontsize=12)
        # Add value labels on bars
        for bar in bars:
            height = bar.get_height()
            ax2.text(bar.get_x() + bar.get_width()/2., height,
                    f'{int(height)}', ha='center', va='bottom', fontsize=11)
        
        # Warehouse distribution pie chart
        ax3 = fig.add_subplot(613)
        warehouse_data = dict(self.stats['warehouse'])
        if warehouse_data:
            # Show top 8 warehouses, group others as "Others"
            sorted_warehouses = sorted(warehouse_data.items(), key=lambda x: x[1], reverse=True)
            top_8 = sorted_warehouses[:8]
            others_count = sum(count for _, count in sorted_warehouses[8:])
            
            chart_data = dict(top_8)
            if others_count > 0:
                chart_data['Others'] = others_count
            
            warehouse_colors = plt.cm.Set3(range(len(chart_data)))
            wedges, texts, autotexts = ax3.pie(chart_data.values(), 
                                               labels=list(chart_data.keys()), 
                                               autopct='%1.1f%%', startangle=90, colors=warehouse_colors)
            ax3.set_title('Warehouse Distribution (Top 8)', fontweight='bold', fontsize=14)
        
        # Shelf distribution bar chart
        ax4 = fig.add_subplot(614)
        shelf_data = dict(self.stats['shelf'])
        if shelf_data:
            # Show top 12 shelves
            sorted_shelves = sorted(shelf_data.items(), key=lambda x: x[0])
            shelf_labels = [f"Shelf {k}" for k, _ in sorted_shelves[:12]]
            shelf_counts = [count for _, count in sorted_shelves[:12]]
            
            bars = ax4.bar(shelf_labels, shelf_counts, color=self.colors['secondary'], alpha=0.7)
            ax4.set_title('Shelf Distribution (Top 12)', fontweight='bold', fontsize=14)
            ax4.set_ylabel('Number of Hubs', fontsize=12)
            ax4.set_xlabel('Shelf Number', fontsize=12)
            ax4.tick_params(axis='x', rotation=45, labelsize=11)
            
            # Add value labels on bars
            for bar in bars:
                height = bar.get_height()
                ax4.text(bar.get_x() + bar.get_width()/2., height,
                        f'{int(height)}', ha='center', va='bottom', fontsize=10)
        
        # Warehouse empty/zero qty chart
        ax5 = fig.add_subplot(615)
        warehouse_stats = self.calculate_warehouse_stats()
        if warehouse_stats:
            # Get top 10 warehouses with most empty + zero qty hubs
            warehouse_problem_data = {}
            for warehouse, stats in warehouse_stats.items():
                total_problem = stats['empty_hubs'] + stats['zero_qty_hubs']
                if total_problem > 0:
                    warehouse_problem_data[warehouse] = total_problem
            
            if warehouse_problem_data:
                sorted_problems = sorted(warehouse_problem_data.items(), key=lambda x: x[1], reverse=True)[:10]
                warehouses = [w for w, _ in sorted_problems]
                problem_counts = [c for _, c in sorted_problems]
                
                bars = ax5.bar(warehouses, problem_counts, color=self.colors['danger'], alpha=0.7)
                ax5.set_title('Warehouses with Most Empty/Zero Qty Hubs (Top 10)', fontweight='bold', fontsize=14)
                ax5.set_ylabel('Problem Hubs Count', fontsize=12)
                ax5.set_xlabel('Warehouse', fontsize=12)
                ax5.tick_params(axis='x', rotation=45, labelsize=11)
                
                # Add value labels on bars
                for bar in bars:
                    height = bar.get_height()
                    ax5.text(bar.get_x() + bar.get_width()/2., height,
                            f'{int(height)}', ha='center', va='bottom', fontsize=10)
        
        # Warehouse top quantity and product count chart
        ax6 = fig.add_subplot(616)
        if warehouse_stats:
            # Get top 8 warehouses by total quantity
            sorted_qty = sorted(warehouse_stats.items(), 
                              key=lambda x: x[1]['total_quantity'], reverse=True)[:8]
            warehouses = [w for w, _ in sorted_qty]
            quantities = [s['total_quantity'] for _, s in sorted_qty]
            
            bars = ax6.bar(warehouses, quantities, color=self.colors['accent'], alpha=0.7)
            ax6.set_title('Warehouses with Highest Quantity (Top 8)', fontweight='bold', fontsize=14)
            ax6.set_ylabel('Total Quantity', fontsize=12)
            ax6.set_xlabel('Warehouse', fontsize=12)
            ax6.tick_params(axis='x', rotation=45, labelsize=11)
            
            # Add value labels on bars
            for bar in bars:
                height = bar.get_height()
                ax6.text(bar.get_x() + bar.get_width()/2., height,
                        f'{int(height)}', ha='center', va='bottom', fontsize=10)
        
        fig.tight_layout(pad=6.0, h_pad=4.0)
        
        # Add extra vertical spacing between charts
        fig.subplots_adjust(hspace=0.8)
        
        # Embed in tkinter for dashboard charts tab
        canvas = FigureCanvasTkAgg(fig, master=self.dashboard_charts_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    
    def update_all_tabs(self):
        self.update_shelves_tab()
        self.update_locations_tab()
        self.update_priority_tab()
        self.update_warehouses_tab()
        self.update_products_tab()
        self.update_scrap_tab()
        self.update_pallet_tab()
        self.update_multi_warehouse_tab()
        self.update_locked_tab()
        self.update_missing_data_tab()
        self.update_expiry_tab()
        self.update_duplicates_tab()
    
    def update_multi_warehouse_tab(self):
        """Update multi-warehouse tab with hubs that have same location but different warehouses/products"""
        # Clear existing widgets
        for widget in self.multi_warehouse_frame.winfo_children():
            widget.destroy()
        
        # Group hubs by location/name
        location_groups = defaultdict(list)
        for hub in self.hubs:
            location = hub.get('name', '')  # Use name as location identifier
            if location:
                location_groups[location].append(hub)
        
        # Filter locations with multiple hubs and analyze warehouse/product assignments
        multi_location_data = []
        for location, hubs_in_location in location_groups.items():
            if len(hubs_in_location) > 1:  # Multiple hubs with same location
                # Get all warehouses for this location
                warehouses_in_location = []
                total_products = 0
                
                for hub in hubs_in_location:
                    warehouse_name = hub.get('warehouse_name', '')
                    if warehouse_name and warehouse_name not in warehouses_in_location:
                        warehouses_in_location.append(warehouse_name)
                    total_products += len(hub.get('in_stock', []))
                
                # Only include if multiple warehouses OR significant product count
                if len(warehouses_in_location) > 1 or total_products > 10:
                    # Get unique hub IDs for this location
                    hub_ids = list(set(h.get('hub_id', '') for h in hubs_in_location))
                    hub_ids_str = ', '.join(str(hid) for hid in hub_ids if hid)
                    
                    # Get location details (use first hub)
                    first_hub = hubs_in_location[0]
                    
                    location_info = {
                        'location': location,
                        'hub_ids': hub_ids_str,
                        'hub_count': len(hubs_in_location),
                        'warehouse_count': len(warehouses_in_location),
                        'warehouses': ', '.join(sorted(warehouses_in_location)),
                        'total_products': total_products,
                        'priority': first_hub.get('priority', 'N/A'),
                        'shelf': first_hub.get('shelf', 'N/A'),
                        'avg_products_per_hub': round(total_products / len(hubs_in_location), 1)
                    }
                    multi_location_data.append(location_info)
        
        # Add export and copy buttons at top
        button_frame = ttk.Frame(self.multi_warehouse_frame)
        button_frame.pack(fill=tk.X, padx=10, pady=5)
        ttk.Button(button_frame, text="📈 Export to Excel", 
                  command=self.export_multi_warehouse_to_excel).pack(side=tk.RIGHT, padx=2)
        ttk.Button(button_frame, text="📋 Copy Data", 
                  command=self.copy_multi_warehouse_to_clipboard).pack(side=tk.RIGHT, padx=2)
        
        # Add summary label
        summary_text = f"Found {len(multi_location_data)} locations with multiple hubs/warehouses"
        ttk.Label(self.multi_warehouse_frame, text=summary_text, font=('Arial', 10, 'bold')).pack(padx=10, pady=5)
        
        # Create treeview for multi-location data
        columns = ('Location', 'Hub IDs', 'Hub Count', 'Warehouse Count', 'Warehouses', 'Total Products', 'Avg Products/Hub', 'Priority', 'Shelf')
        self.multi_warehouse_tree = ttk.Treeview(self.multi_warehouse_frame, columns=columns, show='headings', height=20)
        
        for col in columns:
            self.multi_warehouse_tree.heading(col, text=col)
            if col == 'Warehouses':
                self.multi_warehouse_tree.column(col, width=250)
            elif col == 'Hub IDs':
                self.multi_warehouse_tree.column(col, width=150)
            else:
                self.multi_warehouse_tree.column(col, width=120)
        
        # Add scrollbars
        vsb = ttk.Scrollbar(self.multi_warehouse_frame, orient="vertical", command=self.multi_warehouse_tree.yview)
        hsb = ttk.Scrollbar(self.multi_warehouse_frame, orient="horizontal", command=self.multi_warehouse_tree.xview)
        self.multi_warehouse_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        # Create a container frame for treeview and scrollbars
        tree_container = ttk.Frame(self.multi_warehouse_frame)
        tree_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.multi_warehouse_tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        hsb.pack(side="bottom", fill="x")
        
        # Populate treeview
        for location_info in sorted(multi_location_data, key=lambda x: x['location']):
            self.multi_warehouse_tree.insert('', 'end', values=(
                location_info['location'],
                location_info['hub_ids'],
                location_info['hub_count'],
                location_info['warehouse_count'],
                location_info['warehouses'],
                location_info['total_products'],
                location_info['avg_products_per_hub'],
                location_info['priority'],
                location_info['shelf']
            ))
    
    def export_multi_warehouse_to_excel(self):
        """Export multi-warehouse data to Excel"""
        try:
            filename = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
                initialfile=f"multi_location_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            )
            
            if not filename:
                return
            
            # Get data from treeview
            data = []
            headers = self.multi_warehouse_tree['columns']
            data.append(headers)
            
            for item in self.multi_warehouse_tree.get_children():
                values = self.multi_warehouse_tree.item(item)['values']
                data.append(values)
            
            df = pd.DataFrame(data[1:], columns=data[0])
            df.to_excel(filename, index=False)
            
            messagebox.showinfo("Success", f"Multi-location data exported to {filename}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to export: {str(e)}")
    
    def copy_multi_warehouse_to_clipboard(self):
        """Copy multi-warehouse data to clipboard"""
        try:
            # Get data from treeview
            data = []
            headers = self.multi_warehouse_tree['columns']
            data.append(headers)
            
            for item in self.multi_warehouse_tree.get_children():
                values = self.multi_warehouse_tree.item(item)['values']
                data.append(values)
            
            # Convert to tab-separated string
            clipboard_text = ""
            for row in data:
                clipboard_text += "\t".join(str(cell) for cell in row) + "\n"
            
            # Copy to clipboard
            self.root.clipboard_clear()
            self.root.clipboard_append(clipboard_text)
            
            messagebox.showinfo("Success", f"Copied {len(data)-1} multi-location records to clipboard")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to copy: {str(e)}")
    
    def update_shelves_tab(self):
        # Clear existing items
        for item in self.shelves_tree.get_children():
            self.shelves_tree.delete(item)
        
        # Add shelf data
        for shelf, count in sorted(self.stats['shelf'].items()):
            shelf_hubs = [h for h in self.hubs if h.get('shelf') == shelf]
            with_stock = len([h for h in shelf_hubs if h in self.stats['stock']['stock']])
            zero_qty = len([h for h in shelf_hubs if h in self.stats['stock']['zero']])
            empty = len([h for h in shelf_hubs if h in self.stats['stock']['empty']])
            
            self.shelves_tree.insert('', 'end', values=(shelf, count, with_stock, zero_qty, empty))
    
    def update_locations_tab(self):
        # Clear existing items
        for item in self.locations_tree.get_children():
            self.locations_tree.delete(item)
        
        # Add location data (top 1000)
        for location, count in self.stats['locations'].most_common(1000):
            location_hubs = [h for h in self.hubs if h.get('name') == location]
            with_stock = len([h for h in location_hubs if h in self.stats['stock']['stock']])
            zero_qty = len([h for h in location_hubs if h in self.stats['stock']['zero']])
            
            self.locations_tree.insert('', 'end', values=(location, count, with_stock, zero_qty))
    
    def update_priority_tab(self):
        # Clear existing widgets
        for widget in self.priority_frame.winfo_children():
            widget.destroy()
        
        # Add export and copy buttons at the top
        button_frame = ttk.Frame(self.priority_frame)
        button_frame.pack(fill=tk.X, padx=10, pady=5)
        ttk.Button(button_frame, text="📈 Export to Excel", 
                  command=self.export_priority_to_excel).pack(side=tk.RIGHT, padx=2)
        ttk.Button(button_frame, text="📋 Copy Data", 
                  command=self.copy_priority_to_clipboard).pack(side=tk.RIGHT, padx=2)
        
        # Create priority analysis
        for priority in sorted(self.stats['priority'].keys()):
            frame = ttk.LabelFrame(self.priority_frame, text=f"Priority {priority}", padding=10)
            frame.pack(fill=tk.X, padx=10, pady=5)
            
            prio_hubs = [h for h in self.hubs if h.get('priority') == priority]
            prio_stock = len([h for h in prio_hubs if h in self.stats['stock']['stock']])
            prio_zero = len([h for h in prio_hubs if h in self.stats['stock']['zero']])
            prio_empty = len(prio_hubs) - prio_stock - prio_zero
            
            # Create mini stats
            stats_text = f"Total: {len(prio_hubs)} | With Stock: {prio_stock} | Zero Qty: {prio_zero} | Empty: {prio_empty}"
            ttk.Label(frame, text=stats_text).pack()
            
            # Show details button
            ttk.Button(frame, text="Show Details", 
                      command=lambda p=priority: self.show_priority_details(p)).pack(pady=5)
    
    def update_warehouses_tab(self):
        # Update warehouse combo
        warehouses = sorted(self.stats['warehouse'].keys())
        self.warehouse_combo['values'] = warehouses
        if warehouses and not self.warehouse_var.get():
            self.warehouse_var.set(warehouses[0])
            self.show_warehouse_details()
    
    def update_products_tab(self):
        # Clear existing items
        for item in self.products_tree.get_children():
            self.products_tree.delete(item)
        
        # Add all products
        for hub in self.hubs:
            for product in hub.get('in_stock', []):
                sku = product.get('sku', 'N/A')
                name = product.get('name', 'N/A')
                warehouse = product.get('warehouse_name', 'Unknown')
                quantity = product.get('quantity', 0)
                hub_name = hub.get('name', 'Unknown')
                priority = hub.get('priority', 'N/A')
                shelf = hub.get('shelf', 'N/A')
                
                self.products_tree.insert('', 'end', values=(sku, name, warehouse, quantity, hub_name, priority, shelf))
    
    def update_scrap_tab(self):
        # Clear existing widgets
        for widget in self.scrap_frame.winfo_children():
            widget.destroy()
        
        # Get scrap hubs
        scrap_hubs = [h for h in self.hubs if h.get('is_scrap') == 1]
        
        # Header
        header = ttk.Label(self.scrap_frame, text=f"🗑️ Scrap Hubs: {len(scrap_hubs)} hubs", 
                          font=('Arial', 16, 'bold'))
        header.pack(pady=10)
        
        # Group by priority
        by_priority = defaultdict(list)
        for hub in scrap_hubs:
            prio = hub.get('priority')
            by_priority[prio].append(hub)
        
        # Create frames for each priority
        for priority in sorted(by_priority.keys()):
            frame = ttk.LabelFrame(self.scrap_frame, text=f"Priority {priority} - {len(by_priority[priority])} hubs", padding=10)
            frame.pack(fill=tk.X, padx=10, pady=5)
            
            # Show details button
            ttk.Button(frame, text="Show Details", 
                      command=lambda p=priority: self.show_scrap_priority_details(p)).pack()
    
    def update_pallet_tab(self):
        # Clear existing widgets
        for widget in self.pallet_frame.winfo_children():
            widget.destroy()
        
        # Get pallet hubs
        pallet_hubs = [h for h in self.hubs if h.get('is_pallet') == 1]
        
        # Header
        header = ttk.Label(self.pallet_frame, text=f"📦 Pallet Hubs: {len(pallet_hubs)} hubs", 
                          font=('Arial', 16, 'bold'))
        header.pack(pady=10)
        
        # Group by priority
        by_priority = defaultdict(list)
        for hub in pallet_hubs:
            prio = hub.get('priority')
            by_priority[prio].append(hub)
        
        # Create frames for each priority
        for priority in sorted(by_priority.keys()):
            frame = ttk.LabelFrame(self.pallet_frame, text=f"Priority {priority} - {len(by_priority[priority])} hubs", padding=10)
            frame.pack(fill=tk.X, padx=10, pady=5)
            
            # Show details button
            ttk.Button(frame, text="Show Details", 
                      command=lambda p=priority: self.show_pallet_priority_details(p)).pack()
    
    def update_locked_tab(self):
        # Clear existing widgets
        for widget in self.locked_frame.winfo_children():
            widget.destroy()
        
        # Get locked hubs
        locked_hubs = [h for h in self.hubs if h.get('is_locked') == True]
        
        # Header
        header = ttk.Label(self.locked_frame, text=f"🔒 Locked Hubs: {len(locked_hubs)} hubs", 
                          font=('Arial', 16, 'bold'))
        header.pack(pady=10)
        
        # Group by priority
        by_priority = defaultdict(list)
        for hub in locked_hubs:
            prio = hub.get('priority')
            by_priority[prio].append(hub)
        
        # Create frames for each priority
        for priority in sorted(by_priority.keys()):
            frame = ttk.LabelFrame(self.locked_frame, text=f"Priority {priority} - {len(by_priority[priority])} hubs", padding=10)
            frame.pack(fill=tk.X, padx=10, pady=5)
            
            # Show details button
            ttk.Button(frame, text="Show Details", 
                      command=lambda p=priority: self.show_locked_priority_details(p)).pack()
    
    def update_missing_data_tab(self):
        # Clear existing widgets
        for widget in self.missing_frame.winfo_children():
            widget.destroy()
        
        # Find hubs with missing data
        missing_name_hubs = []
        missing_sku_products = []
        
        # Check for missing hub names
        for hub in self.hubs:
            if not hub.get('name') or hub.get('name', '').strip() == '':
                missing_name_hubs.append(hub)
        
        # Check for missing SKUs in products
        for hub in self.hubs:
            for product in hub.get('in_stock', []):
                if not product.get('sku') or product.get('sku', '').strip() == '':
                    missing_sku_products.append({
                        'hub_name': hub.get('name', 'Unknown'),
                        'product_name': product.get('name', 'Unknown'),
                        'warehouse': product.get('warehouse_name', 'Unknown'),
                        'quantity': product.get('quantity', 0),
                        'hub': hub
                    })
        
        # Header
        header = ttk.Label(self.missing_frame, 
                          text=f"❓ Missing Data: {len(missing_name_hubs)} hubs, {len(missing_sku_products)} products", 
                          font=('Arial', 16, 'bold'))
        header.pack(pady=10)
        
        # Missing hub names section
        if missing_name_hubs:
            name_frame = ttk.LabelFrame(self.missing_frame, text=f"Hubs with Missing Names ({len(missing_name_hubs)})", padding=10)
            name_frame.pack(fill=tk.X, padx=10, pady=5)
            
            ttk.Button(name_frame, text="Show Details", 
                      command=lambda: self.show_missing_names_details(missing_name_hubs)).pack()
        
        # Missing SKUs section
        if missing_sku_products:
            sku_frame = ttk.LabelFrame(self.missing_frame, text=f"Products with Missing SKUs ({len(missing_sku_products)})", padding=10)
            sku_frame.pack(fill=tk.X, padx=10, pady=5)
            
            ttk.Button(sku_frame, text="Show Details", 
                      command=lambda: self.show_missing_sku_details(missing_sku_products)).pack()
    
    def update_expiry_tab(self):
        # Clear existing widgets
        for widget in self.expiry_frame.winfo_children():
            widget.destroy()
        
        # Find products with expiry dates
        expiry_products = []
        
        for hub in self.hubs:
            for product in hub.get('in_stock', []):
                if product.get('expiry_date'):  # Check if expiry_date field exists and is not empty
                    expiry_products.append({
                        'hub_name': hub.get('name', 'Unknown'),
                        'sku': product.get('sku', 'N/A'),
                        'product_name': product.get('name', 'Unknown'),
                        'warehouse': product.get('warehouse_name', 'Unknown'),
                        'quantity': product.get('quantity', 0),
                        'expiry_date': product.get('expiry_date', 'Unknown'),
                        'hub': hub,
                        'product': product
                    })
        
        # Header
        header = ttk.Label(self.expiry_frame, 
                          text=f"📅 Products with Expiry Dates: {len(expiry_products)} products", 
                          font=('Arial', 16, 'bold'))
        header.pack(pady=10)
        
        if expiry_products:
            # Sort by expiry date
            expiry_products.sort(key=lambda x: x['expiry_date'])
            
            # Create treeview with sorting
            columns = ('Hub Name', 'SKU', 'Product Name', 'Warehouse', 'Quantity', 'Expiry Date')
            self.expiry_tree = ttk.Treeview(self.expiry_frame, columns=columns, show='headings', height=15)
            
            for col in columns:
                self.expiry_tree.heading(col, text=col, command=lambda c=col: self.sort_treeview('expiry', c))
                self.expiry_tree.column(col, width=120)
            
            # Add data
            for product in expiry_products:
                self.expiry_tree.insert('', 'end', values=(
                    product['hub_name'],
                    product['sku'],
                    product['product_name'],
                    product['warehouse'],
                    product['quantity'],
                    product['expiry_date']
                ))
            
            # Export button
            export_frame = ttk.Frame(self.expiry_frame)
            export_frame.pack(fill=tk.X, padx=10, pady=5)
            ttk.Button(export_frame, text="📈 Export to Excel", 
                      command=lambda: self.export_treeview_to_excel(self.expiry_tree, 'expiry')).pack(side=tk.RIGHT)
            
            # Add scrollbars
            vsb = ttk.Scrollbar(self.expiry_frame, orient="vertical", command=self.expiry_tree.yview)
            hsb = ttk.Scrollbar(self.expiry_frame, orient="horizontal", command=self.expiry_tree.xview)
            self.expiry_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
            
            self.expiry_tree.pack(side="left", fill="both", expand=True, padx=10, pady=5)
            vsb.pack(side="right", fill="y")
            hsb.pack(side="bottom", fill="x")
    
    def update_duplicates_tab(self):
        # Clear existing widgets
        for widget in self.duplicates_frame.winfo_children():
            widget.destroy()
        
        # Find duplicates by product name and SKU
        product_duplicates = defaultdict(list)
        sku_duplicates = defaultdict(list)
        
        for hub in self.hubs:
            for product in hub.get('in_stock', []):
                product_name = product.get('name', 'Unknown')
                sku = product.get('sku', 'Unknown')
                
                # Track by product name
                product_key = f"{product_name}_{product.get('warehouse_name', 'Unknown')}"
                product_duplicates[product_key].append({
                    'hub_name': hub.get('name', 'Unknown'),
                    'sku': sku,
                    'product_name': product_name,
                    'warehouse': product.get('warehouse_name', 'Unknown'),
                    'quantity': product.get('quantity', 0),
                    'hub': hub
                })
                
                # Track by SKU
                if sku and sku != 'Unknown':
                    sku_key = f"{sku}_{product.get('warehouse_name', 'Unknown')}"
                    sku_duplicates[sku_key].append({
                        'hub_name': hub.get('name', 'Unknown'),
                        'sku': sku,
                        'product_name': product_name,
                        'warehouse': product.get('warehouse_name', 'Unknown'),
                        'quantity': product.get('quantity', 0),
                        'hub': hub
                    })
        
        # Header
        header = ttk.Label(self.duplicates_frame, 
                          text=f"🔄 Duplicates Analysis: {sum(len(v) for v in product_duplicates.values() if len(v) > 1)} duplicate groups", 
                          font=('Arial', 16, 'bold'))
        header.pack(pady=10)
        
        # Product name duplicates
        name_duplicates = {k: v for k, v in product_duplicates.items() if len(v) > 1}
        if name_duplicates:
            name_frame = ttk.LabelFrame(self.duplicates_frame, text=f"Product Name Duplicates ({len(name_duplicates)} groups)", padding=10)
            name_frame.pack(fill=tk.X, padx=10, pady=5)
            
            ttk.Button(name_frame, text="Show Details", 
                      command=lambda: self.show_duplicates_details(name_duplicates, 'Product Name')).pack()
        
        # SKU duplicates
        sku_dup_data = {k: v for k, v in sku_duplicates.items() if len(v) > 1}
        if sku_dup_data:
            sku_frame = ttk.LabelFrame(self.duplicates_frame, text=f"SKU Duplicates ({len(sku_dup_data)} groups)", padding=10)
            sku_frame.pack(fill=tk.X, padx=10, pady=5)
            
            ttk.Button(sku_frame, text="Show Details", 
                      command=lambda: self.show_duplicates_details(sku_dup_data, 'SKU')).pack()
    
    def show_shelf_details(self, event):
        selection = self.shelves_tree.selection()
        if selection:
            item = self.shelves_tree.item(selection[0])
            shelf = item['values'][0]
            self.show_hub_details_window(f"Shelf {shelf}", [h for h in self.hubs if h.get('shelf') == shelf])
    
    def show_priority_details(self, priority):
        prio_hubs = [h for h in self.hubs if h.get('priority') == priority]
        self.show_hub_details_window(f"Priority {priority}", prio_hubs)
    
    def show_scrap_priority_details(self, priority):
        scrap_hubs = [h for h in self.hubs if h.get('is_scrap') == 1 and h.get('priority') == priority]
        self.show_hub_details_window(f"Scrap - Priority {priority}", scrap_hubs)
    
    def show_pallet_priority_details(self, priority):
        pallet_hubs = [h for h in self.hubs if h.get('is_pallet') == 1 and h.get('priority') == priority]
        self.show_hub_details_window(f"Pallet - Priority {priority}", pallet_hubs)
    
    def show_locked_priority_details(self, priority):
        locked_hubs = [h for h in self.hubs if h.get('is_locked') == True and h.get('priority') == priority]
        self.show_hub_details_window(f"Locked - Priority {priority}", locked_hubs)
    
    def show_missing_names_details(self, missing_hubs):
        # Create new window
        window = tk.Toplevel(self.root)
        window.title(f"Hubs with Missing Names - {len(missing_hubs)} hubs")
        window.geometry("900x600")
        
        # Create treeview with sorting
        columns = ('Hub Name', 'Priority', 'Shelf', 'Products', 'Stock Status')
        tree = ttk.Treeview(window, columns=columns, show='headings')
        
        # Add sorting to each column
        for col in columns:
            tree.heading(col, text=col, command=lambda c=col, t=tree: self.sort_popup_treeview(t, c))
            tree.column(col, width=150)
        
        # Add data
        for hub in missing_hubs:
            name = hub.get('name', 'MISSING')
            priority = hub.get('priority', 'N/A')
            shelf = hub.get('shelf', 'N/A')
            products = len(hub.get('in_stock', []))
            
            # Determine stock status
            if products == 0:
                stock_status = "Empty"
            else:
                quantities = [p.get('quantity', 0) for p in hub.get('in_stock', [])]
                if all(q == 0 for q in quantities):
                    stock_status = "Zero Qty"
                else:
                    stock_status = "With Stock"
            
            tree.insert('', 'end', values=(name, priority, shelf, products, stock_status))
        
        # Add export button
        export_frame = ttk.Frame(window)
        export_frame.pack(fill=tk.X, padx=10, pady=5)
        ttk.Button(export_frame, text="📈 Export to Excel", 
                  command=lambda: self.export_popup_treeview_to_excel(tree, 'missing_names')).pack(side=tk.RIGHT)
        
        # Add scrollbars
        vsb = ttk.Scrollbar(window, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(window, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        hsb.pack(side="bottom", fill="x")
    
    def show_missing_sku_details(self, missing_products):
        # Create new window
        window = tk.Toplevel(self.root)
        window.title(f"Products with Missing SKUs - {len(missing_products)} products")
        window.geometry("1000x600")
        
        # Create treeview with sorting
        columns = ('Hub Name', 'Product Name', 'Warehouse', 'Quantity')
        tree = ttk.Treeview(window, columns=columns, show='headings')
        
        # Add sorting to each column
        for col in columns:
            tree.heading(col, text=col, command=lambda c=col, t=tree: self.sort_popup_treeview(t, c))
            tree.column(col, width=180)
        
        # Add data
        for product in missing_products:
            tree.insert('', 'end', values=(
                product['hub_name'],
                product['product_name'],
                product['warehouse'],
                product['quantity']
            ))
        
        # Add export button
        export_frame = ttk.Frame(window)
        export_frame.pack(fill=tk.X, padx=10, pady=5)
        ttk.Button(export_frame, text="📈 Export to Excel", 
                  command=lambda: self.export_popup_treeview_to_excel(tree, 'missing_skus')).pack(side=tk.RIGHT)
        
        # Add scrollbars
        vsb = ttk.Scrollbar(window, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(window, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        hsb.pack(side="bottom", fill="x")
    
    def show_duplicate_skus_details(self, duplicate_skus):
        """Show duplicate SKUs in a popup window"""
        # Create new window
        window = tk.Toplevel(self.root)
        window.title(f"Duplicate SKUs - {len(duplicate_skus)} SKUs")
        window.geometry("1000x600")
        
        # Create treeview with sorting
        columns = ('SKU', 'Duplicate Count', 'Total Quantity', 'Locations', 'Product Names')
        tree = ttk.Treeview(window, columns=columns, show='headings')
        
        for col in columns:
            tree.heading(col, text=col, command=lambda c=col: self.sort_popup_treeview(tree, c))
            if col == 'Locations':
                tree.column(col, width=300)
            elif col == 'Product Names':
                tree.column(col, width=250)
            else:
                tree.column(col, width=120)
        
        # Add scrollbars
        vsb = ttk.Scrollbar(window, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(window, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        hsb.pack(side="bottom", fill="x")
        
        # Populate treeview
        for sku_info in sorted(duplicate_skus, key=lambda x: x['sku']):
            locations_str = ', '.join(sorted(sku_info['locations']))
            product_names = list(set(p.get('product_name', 'Unknown') for p in duplicate_skus if p.get('sku', '') == sku_info['sku']))
            product_names_str = ', '.join(sorted(product_names))
            
            tree.insert('', 'end', values=(
                sku_info['sku'],
                sku_info['duplicate_count'],
                sku_info['total_quantity'],
                locations_str,
                product_names_str
            ))
        
        # Add export button
        export_frame = ttk.Frame(window)
        export_frame.pack(fill=tk.X, padx=10, pady=5)
        ttk.Button(export_frame, text="📈 Export to Excel", 
                  command=lambda: self.export_popup_treeview_to_excel(tree, 'duplicate_skus')).pack(side=tk.RIGHT, padx=2)
        ttk.Button(export_frame, text="📋 Copy Table", 
                  command=lambda: self.copy_popup_treeview_to_clipboard(tree)).pack(side=tk.RIGHT, padx=2)
    
    def show_duplicate_product_names_details(self, duplicate_product_names):
        """Show duplicate product names in a popup window"""
        # Create new window
        window = tk.Toplevel(self.root)
        window.title(f"Duplicate Product Names - {len(duplicate_product_names)} Names")
        window.geometry("1200x600")
        
        # Create treeview with sorting
        columns = ('Product Name', 'Duplicate Count', 'Total Quantity', 'Locations', 'SKUs')
        tree = ttk.Treeview(window, columns=columns, show='headings')
        
        for col in columns:
            tree.heading(col, text=col, command=lambda c=col: self.sort_popup_treeview(tree, c))
            if col == 'Locations':
                tree.column(col, width=250)
            elif col == 'SKUs':
                tree.column(col, width=200)
            else:
                tree.column(col, width=120)
        
        # Add scrollbars
        vsb = ttk.Scrollbar(window, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(window, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        hsb.pack(side="bottom", fill="x")
        
        # Populate treeview
        for product_info in sorted(duplicate_product_names, key=lambda x: x['product_name']):
            locations_str = ', '.join(sorted(product_info['locations']))
            skus_str = ', '.join(sorted(product_info['skus']))
            
            tree.insert('', 'end', values=(
                product_info['product_name'],
                product_info['duplicate_count'],
                product_info['total_quantity'],
                locations_str,
                skus_str
            ))
        
        # Add export button
        export_frame = ttk.Frame(window)
        export_frame.pack(fill=tk.X, padx=10, pady=5)
        ttk.Button(export_frame, text="📈 Export to Excel", 
                  command=lambda: self.export_popup_treeview_to_excel(tree, 'duplicate_product_names')).pack(side=tk.RIGHT, padx=2)
        ttk.Button(export_frame, text="📋 Copy Table", 
                  command=lambda: self.copy_popup_treeview_to_clipboard(tree)).pack(side=tk.RIGHT, padx=2)
    
    def show_expired_products_details(self, expired_products):
        # Create new window
        window = tk.Toplevel(self.root)
        window.title(f"Expired Products - {len(expired_products)} products")
        window.geometry("1200x600")
        
        # Create treeview with sorting
        columns = ('Hub Name', 'SKU', 'Product Name', 'Warehouse', 'Quantity', 'Expiry Date')
        tree = ttk.Treeview(window, columns=columns, show='headings')
        
        # Add sorting to each column
        for col in columns:
            tree.heading(col, text=col, command=lambda c=col, t=tree: self.sort_popup_treeview(t, c))
            tree.column(col, width=150)
        
        # Add data
        for product in expired_products:
            tree.insert('', 'end', values=(
                product['hub_name'],
                product['sku'],
                product['product_name'],
                product['warehouse'],
                product['quantity'],
                product['expiry_date']
            ))
        
        # Add export button
        export_frame = ttk.Frame(window)
        export_frame.pack(fill=tk.X, padx=10, pady=5)
        ttk.Button(export_frame, text="📈 Export to Excel", 
                  command=lambda: self.export_popup_treeview_to_excel(tree, 'expired_products')).pack(side=tk.RIGHT)
        
        # Add scrollbars
        vsb = ttk.Scrollbar(window, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(window, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        hsb.pack(side="bottom", fill="x")
    
    def show_duplicates_details(self, duplicates_data, duplicate_type):
        # Create new window
        window = tk.Toplevel(self.root)
        window.title(f"{duplicate_type} Duplicates - {len(duplicates_data)} groups")
        window.geometry("1400x600")
        
        # Create treeview with sorting
        columns = ('Key', 'Hub Name', 'SKU', 'Product Name', 'Warehouse', 'Quantity')
        tree = ttk.Treeview(window, columns=columns, show='headings')
        
        # Add sorting to each column
        for col in columns:
            tree.heading(col, text=col, command=lambda c=col, t=tree: self.sort_popup_treeview(t, c))
            tree.column(col, width=180)
        
        # Add data
        for key, duplicates in duplicates_data.items():
            for i, duplicate in enumerate(duplicates):
                tree.insert('', 'end', values=(
                    key,
                    duplicate['hub_name'],
                    duplicate['sku'],
                    duplicate['product_name'],
                    duplicate['warehouse'],
                    duplicate['quantity']
                ))
        
        # Add export button
        export_frame = ttk.Frame(window)
        export_frame.pack(fill=tk.X, padx=10, pady=5)
        ttk.Button(export_frame, text="📈 Export to Excel", 
                  command=lambda: self.export_popup_treeview_to_excel(tree, f'{duplicate_type.lower()}_duplicates')).pack(side=tk.RIGHT)
        
        # Add scrollbars
        vsb = ttk.Scrollbar(window, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(window, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        hsb.pack(side="bottom", fill="x")
    
    def copy_treeview_to_clipboard(self, tree):
        """Copy treeview data to clipboard"""
        try:
            # Get all data
            data = []
            headers = tree['columns']
            data.append(headers)
            
            for item in tree.get_children():
                values = tree.item(item)['values']
                data.append(values)
            
            # Convert to tab-separated string
            clipboard_text = ""
            for row in data:
                clipboard_text += "\t".join(str(cell) for cell in row) + "\n"
            
            # Copy to clipboard
            self.root.clipboard_clear()
            self.root.clipboard_append(clipboard_text)
            
            messagebox.showinfo("Success", f"Copied {len(data)-1} rows to clipboard")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to copy: {str(e)}")
    
    def export_priority_to_excel(self):
        """Export priority data to Excel"""
        try:
            filename = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
                initialfile=f"priority_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            )
            
            if not filename:
                return
            
            # Create priority data
            priority_data = []
            priority_data.append(['Priority', 'Total Hubs', 'With Stock', 'Zero Qty', 'Empty'])
            
            for priority in sorted(self.stats['priority'].keys()):
                prio_hubs = [h for h in self.hubs if h.get('priority') == priority]
                prio_stock = len([h for h in prio_hubs if h in self.stats['stock']['stock']])
                prio_zero = len([h for h in prio_hubs if h in self.stats['stock']['zero']])
                prio_empty = len(prio_hubs) - prio_stock - prio_zero
                
                priority_data.append([priority, len(prio_hubs), prio_stock, prio_zero, prio_empty])
            
            df = pd.DataFrame(priority_data[1:], columns=priority_data[0])
            df.to_excel(filename, index=False)
            
            messagebox.showinfo("Success", f"Priority data exported to {filename}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to export: {str(e)}")
    
    def copy_priority_to_clipboard(self):
        """Copy priority data to clipboard"""
        try:
            # Create priority data
            priority_data = []
            priority_data.append(['Priority', 'Total Hubs', 'With Stock', 'Zero Qty', 'Empty'])
            
            for priority in sorted(self.stats['priority'].keys()):
                prio_hubs = [h for h in self.hubs if h.get('priority') == priority]
                prio_stock = len([h for h in prio_hubs if h in self.stats['stock']['stock']])
                prio_zero = len([h for h in prio_hubs if h in self.stats['stock']['zero']])
                prio_empty = len(prio_hubs) - prio_stock - prio_zero
                
                priority_data.append([priority, len(prio_hubs), prio_stock, prio_zero, prio_empty])
            
            # Convert to tab-separated string
            clipboard_text = ""
            for row in priority_data:
                clipboard_text += "\t".join(str(cell) for cell in row) + "\n"
            
            # Copy to clipboard
            self.root.clipboard_clear()
            self.root.clipboard_append(clipboard_text)
            
            messagebox.showinfo("Success", f"Copied {len(priority_data)-1} priority levels to clipboard")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to copy: {str(e)}")
    
    def show_hub_details_window(self, title, hubs):
        # Create new window
        window = tk.Toplevel(self.root)
        window.title(f"{title} - {len(hubs)} hubs")
        window.geometry("900x600")
        
        # Create treeview with sorting
        columns = ('Name', 'Priority', 'Shelf', 'Products', 'Stock Status')
        tree = ttk.Treeview(window, columns=columns, show='headings')
        
        # Add sorting to each column
        for col in columns:
            tree.heading(col, text=col, command=lambda c=col, t=tree: self.sort_popup_treeview(t, c))
            tree.column(col, width=150)
        
        # Add data
        for hub in hubs:
            name = hub.get('name', 'Unknown')
            priority = hub.get('priority', 'N/A')
            shelf = hub.get('shelf', 'N/A')
            products = len(hub.get('in_stock', []))
            
            # Determine stock status
            if products == 0:
                stock_status = "Empty"
            else:
                quantities = [p.get('quantity', 0) for p in hub.get('in_stock', [])]
                if all(q == 0 for q in quantities):
                    stock_status = "Zero Qty"
                else:
                    stock_status = "With Stock"
            
            tree.insert('', 'end', values=(name, priority, shelf, products, stock_status))
        
        # Add export button
        export_frame = ttk.Frame(window)
        export_frame.pack(fill=tk.X, padx=10, pady=5)
        ttk.Button(export_frame, text="📈 Export to Excel", 
                  command=lambda: self.export_popup_treeview_to_excel(tree, title.lower().replace(' ', '_'))).pack(side=tk.RIGHT)
        
        # Add scrollbars
        vsb = ttk.Scrollbar(window, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(window, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        hsb.pack(side="bottom", fill="x")
    
    def filter_warehouse_products(self, event=None):
        warehouse = self.warehouse_var.get()
        if not warehouse:
            return
        
        search_term = self.warehouse_search.get().lower()
        
        # Clear existing items
        for item in self.warehouse_products_tree.get_children():
            self.warehouse_products_tree.delete(item)
        
        # Add filtered products for selected warehouse
        for hub in self.hubs:
            for product in hub.get('in_stock', []):
                if product.get('warehouse_name') == warehouse:
                    sku = product.get('sku', 'N/A')
                    name = product.get('name', 'N/A')
                    quantity = product.get('quantity', 0)
                    hub_name = hub.get('name', 'Unknown')
                    
                    # Apply search filter
                    if search_term in sku.lower() or search_term in name.lower() or search_term in hub_name.lower():
                        self.warehouse_products_tree.insert('', 'end', values=(sku, name, quantity, hub_name))

    def show_warehouse_details(self, event=None):
        warehouse = self.warehouse_var.get()
        if not warehouse:
            return
        
        # Clear search field
        self.warehouse_search.delete(0, tk.END)
        
        # Clear existing items
        for item in self.warehouse_products_tree.get_children():
            self.warehouse_products_tree.delete(item)
        
        # Add products for selected warehouse
        for hub in self.hubs:
            for product in hub.get('in_stock', []):
                if product.get('warehouse_name') == warehouse:
                    sku = product.get('sku', 'N/A')
                    name = product.get('name', 'N/A')
                    quantity = product.get('quantity', 0)
                    hub_name = hub.get('name', 'Unknown')
                    
                    self.warehouse_products_tree.insert('', 'end', values=(sku, name, quantity, hub_name))
    
    def filter_locations(self, event=None):
        search_term = self.location_search.get().lower()
        
        # Clear existing items
        for item in self.locations_tree.get_children():
            self.locations_tree.delete(item)
        
        # Add filtered locations
        for location, count in self.stats['locations'].most_common():
            if search_term in location.lower():
                location_hubs = [h for h in self.hubs if h.get('name') == location]
                with_stock = len([h for h in location_hubs if h in self.stats['stock']['stock']])
                zero_qty = len([h for h in location_hubs if h in self.stats['stock']['zero']])
                
                self.locations_tree.insert('', 'end', values=(location, count, with_stock, zero_qty))
    
    def sort_popup_treeview(self, tree, column):
        """Sort popup treeview by column"""
        # Get all data
        data = []
        for item in tree.get_children():
            values = tree.item(item)['values']
            data.append((item, values))
        
        # Get column index
        columns = tree['columns']
        col_idx = columns.index(column)
        
        # Sort data using same tuple approach as main treeview
        def sort_key(item):
            values = item[1]
            value = values[col_idx]
            # Create a tuple that handles both numeric and string sorting
            try:
                # Try to convert to number first
                num_value = float(value)
                # Return (0, number) for numeric values (comes before strings)
                return (0, num_value)
            except (ValueError, TypeError):
                # Return (1, lowercase string) for string values (comes after numbers)
                return (1, str(value).lower())
        
        data.sort(key=sort_key)
        
        # Reorder items
        for idx, (item, values) in enumerate(data):
            tree.move(item, '', idx)
    
    def export_popup_treeview_to_excel(self, tree, sheet_name):
        """Export popup treeview data to Excel"""
        try:
            filename = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
                initialfile=f"{sheet_name}_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            )
            
            if not filename:
                return
            
            # Get data from treeview
            data = []
            columns = tree['columns']
            
            # Add header
            data.append(columns)
            
            # Add rows
            for item in tree.get_children():
                values = tree.item(item)['values']
                data.append(values)
            
            # Create DataFrame and export
            df = pd.DataFrame(data[1:], columns=data[0])
            df.to_excel(filename, index=False, sheet_name=sheet_name.replace('_', ' ').title())
            
            messagebox.showinfo("Success", f"Data exported to {filename}")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to export: {str(e)}")

    def copy_treeview_to_clipboard(self, tree):
        """Copy treeview data to clipboard"""
        try:
            # Get all data
            data = []
            headers = tree['columns']
            data.append(headers)
            
            for item in tree.get_children():
                values = tree.item(item)['values']
                data.append(values)
            
            # Convert to tab-separated string
            clipboard_text = ""
            for row in data:
                clipboard_text += "\t".join(str(cell) for cell in row) + "\n"
            
            # Copy to clipboard
            self.root.clipboard_clear()
            self.root.clipboard_append(clipboard_text)
            
            messagebox.showinfo("Success", f"Copied {len(data)-1} rows to clipboard")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to copy: {str(e)}")

    def export_treeview_to_excel(self, tree, sheet_name):
        """Export treeview data to Excel"""
        try:
            filename = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
                initialfile=f"{sheet_name}_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            )
            
            if not filename:
                return
            
            # Get data from treeview
            data = []
            columns = tree['columns']
            
            # Add header
            data.append(columns)
            
            # Add rows
            for item in tree.get_children():
                values = tree.item(item)['values']
                data.append(values)
            
            # Create DataFrame and export
            df = pd.DataFrame(data[1:], columns=data[0])
            df.to_excel(filename, index=False, sheet_name=sheet_name.capitalize())
            
            messagebox.showinfo("Success", f"Data exported to {filename}")
            self.status_label.config(text=f"Exported {sheet_name} to Excel")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to export: {str(e)}")
    
    def export_all_to_excel(self):
        """Export all data to Excel with multiple sheets"""
        if not self.data:
            messagebox.showwarning("Warning", "No data to export")
            return
        
        try:
            filename = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
                initialfile=f"warehouse_complete_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            )
            
            if not filename:
                return
            
            with pd.ExcelWriter(filename, engine='openpyxl') as writer:
                # Export shelves data
                shelves_data = []
                shelves_data.append(['Shelf', 'Total Hubs', 'With Stock', 'Zero Qty', 'Empty'])
                for item in self.shelves_tree.get_children():
                    shelves_data.append(self.shelves_tree.item(item)['values'])
                shelves_df = pd.DataFrame(shelves_data[1:], columns=shelves_data[0])
                shelves_df.to_excel(writer, sheet_name='Shelves', index=False)
                
                # Export locations data
                locations_data = []
                locations_data.append(['Location', 'Total Hubs', 'With Stock', 'Zero Qty'])
                for item in self.locations_tree.get_children():
                    locations_data.append(self.locations_tree.item(item)['values'])
                locations_df = pd.DataFrame(locations_data[1:], columns=locations_data[0])
                locations_df.to_excel(writer, sheet_name='Locations', index=False)
                
                # Export products data
                products_data = []
                products_data.append(['SKU', 'Product Name', 'Warehouse', 'Quantity', 'Hub Name', 'Priority', 'Shelf'])
                for item in self.products_tree.get_children():
                    products_data.append(self.products_tree.item(item)['values'])
                products_df = pd.DataFrame(products_data[1:], columns=products_data[0])
                products_df.to_excel(writer, sheet_name='Products', index=False)
                
                # Export summary statistics
                summary_data = {
                    'Metric': ['Total Hubs', 'With Stock', 'Zero Qty', 'Empty', 'Total Warehouses', 'Locked Hubs', 'Scrap Hubs', 'Pallet Hubs'],
                    'Count': [
                        len(self.hubs),
                        len(self.stats['stock']['stock']),
                        len(self.stats['stock']['zero']),
                        len(self.stats['stock']['empty']),
                        len(self.stats['warehouse']),
                        self.stats['status']['locked'],
                        self.stats['status']['scrap'],
                        self.stats['status']['pallet']
                    ]
                }
                summary_df = pd.DataFrame(summary_data)
                summary_df.to_excel(writer, sheet_name='Summary', index=False)
                
                # Export priority breakdown
                priority_data = []
                priority_data.append(['Priority', 'Count'])
                for priority in sorted(self.stats['priority'].keys()):
                    priority_data.append([priority, self.stats['priority'][priority]])
                priority_df = pd.DataFrame(priority_data[1:], columns=priority_data[0])
                priority_df.to_excel(writer, sheet_name='Priorities', index=False)
            
            messagebox.showinfo("Success", f"All data exported to {filename}")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to export: {str(e)}")
    
    def sort_treeview(self, tree_name, column):
        """Sort treeview by column"""
        tree = getattr(self, f"{tree_name}_tree")
        sort_state = self.sort_states[tree_name]
        
        # Toggle sort direction
        if sort_state['column'] == column:
            sort_state['reverse'] = not sort_state['reverse']
        else:
            sort_state['column'] = column
            sort_state['reverse'] = False
        
        # Get all data
        data = []
        for item in tree.get_children():
            values = tree.item(item)['values']
            data.append((item, values))
        
        # Get column index
        columns = tree['columns']
        col_idx = columns.index(column)
        
        # Sort data
        def sort_key(item):
            values = item[1]
            value = values[col_idx]
            # Create a tuple that handles both numeric and string sorting
            try:
                # Try to convert to number first
                num_value = float(value)
                # Return (0, number) for numeric values (comes before strings)
                return (0, num_value)
            except (ValueError, TypeError):
                # Return (1, lowercase string) for string values (comes after numbers)
                return (1, str(value).lower())
        
        data.sort(key=sort_key, reverse=sort_state['reverse'])
        
        # Reorder items
        for idx, (item, values) in enumerate(data):
            tree.move(item, '', idx)
    
    def filter_products(self, event=None):
        search_term = self.product_search.get().lower()
        
        # Clear existing items
        for item in self.products_tree.get_children():
            self.products_tree.delete(item)
        
        # Add filtered products
        for hub in self.hubs:
            for product in hub.get('in_stock', []):
                sku = product.get('sku', 'N/A')
                name = product.get('name', 'N/A')
                warehouse = product.get('warehouse_name', 'Unknown')
                quantity = product.get('quantity', 0)
                hub_name = hub.get('name', 'Unknown')
                priority = hub.get('priority', 'N/A')
                shelf = hub.get('shelf', 'N/A')
                
                if search_term in sku.lower() or search_term in name.lower():
                    self.products_tree.insert('', 'end', values=(sku, name, warehouse, quantity, hub_name, priority, shelf))
    
    def refresh_data(self):
        if self.data:
            self.calculate_stats()
            self.update_dashboard()
            self.update_all_tabs()
            self.status_label.config(text="Data refreshed")
    
    def export_report(self):
        if not self.data:
            messagebox.showwarning("Warning", "No data to export")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write("WAREHOUSE ANALYTICS REPORT\n")
                    f.write("=" * 50 + "\n")
                    f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                    
                    # Summary stats
                    f.write("SUMMARY STATISTICS\n")
                    f.write("-" * 20 + "\n")
                    f.write(f"Total Hubs: {len(self.hubs)}\n")
                    f.write(f"Hubs with Stock: {len(self.stats['stock']['stock'])}\n")
                    f.write(f"Hubs with Zero Qty: {len(self.stats['stock']['zero'])}\n")
                    f.write(f"Empty Hubs: {len(self.stats['stock']['empty'])}\n")
                    f.write(f"Total Warehouses: {len(self.stats['warehouse'])}\n")
                    f.write(f"Locked Hubs: {self.stats['status']['locked']}\n")
                    f.write(f"Scrap Hubs: {self.stats['status']['scrap']}\n")
                    f.write(f"Pallet Hubs: {self.stats['status']['pallet']}\n\n")
                    
                    # Priority breakdown
                    f.write("PRIORITY BREAKDOWN\n")
                    f.write("-" * 20 + "\n")
                    for priority in sorted(self.stats['priority'].keys()):
                        f.write(f"Priority {priority}: {self.stats['priority'][priority]} hubs\n")
                    
                    f.write(f"\nReport exported successfully to {filename}")
                
                messagebox.showinfo("Success", f"Report exported to {filename}")
                self.status_label.config(text=f"Report exported to {filename}")
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to export report: {str(e)}")

def main():
    root = tk.Tk()
    app = WarehouseAnalyzerGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
