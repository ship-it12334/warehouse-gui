@echo off
echo Starting Warehouse Analytics Pro...
"C:\Users\unkno\AppData\Local\Microsoft\WindowsApps\python.exe" warehouse_analyzer_gui.py
pause
