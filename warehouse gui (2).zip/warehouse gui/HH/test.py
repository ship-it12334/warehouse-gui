#!/usr/bin/env python3
import requests
import json
import time
import os
import sys
from tqdm import tqdm  # pip install tqdm

# Windows UTF-8 fix
if sys.platform.startswith('win'):
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

print("🚀 NextLevel Hub Scraper v2.0")

# Config
TOKEN = "461818415"
HUB_ID = 1
MOBILE_SECRET = "473821fjisak8592"
BASE_URL = "https://api.nextlevel.delivery"
DELAY = 2.5
POSITIONS_FILE = f"positions_hub_{HUB_ID}.txt"
DATA_FILE = f"hub_{HUB_ID}_positions_full.json"
PROGRESS_FILE = f"progress_hub_{HUB_ID}.json"

session = requests.Session()
current_user_key = None

def save_json(data, filename):
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def get_auth_key():
    global current_user_key
    login_url = f"{BASE_URL}/admin/login/qr"
    headers = {
        "accept": "*/*", "content-type": "application/json",
        "origin": "https://admin.nextlevel.delivery",
        "x-mobile-secret": MOBILE_SECRET
    }
    data = {"token": TOKEN}
    
    resp = session.post(login_url, headers=headers, json=data, timeout=30)
    resp.raise_for_status()
    result = resp.json()
    
    if result.get("success"):
        current_user_key = result["key"]
        return True
    return False

def load_positions():
    if not os.path.exists(POSITIONS_FILE):
        print(f"❌ Create {POSITIONS_FILE} first!")
        sys.exit(1)
    with open(POSITIONS_FILE, 'r', encoding='utf-8') as f:
        return [int(l.strip()) for l in f if l.strip()]

def load_progress():
    def_progress = {"next": 0, "count": 0}
    if os.path.exists(PROGRESS_FILE):
        try:
            with open(PROGRESS_FILE, 'r', encoding='utf-8') as f:
                prog = json.load(f)
                return prog.get("next", 0), prog.get("count", 0)
        except:
            pass
    return 0, 0

def save_progress(idx, count):
    prog = {"next": idx, "count": count}
    with open(PROGRESS_FILE, 'w', encoding='utf-8') as f:
        json.dump(prog, f)

def main():
    if not get_auth_key():
        print("❌ Auth failed")
        return
    
    positions = load_positions()
    start_idx, saved_count = load_progress()
    
    print(f"\n📊 {saved_count}/{len(positions)} ({start_idx} next)")
    
    if start_idx >= len(positions):
        print("✅ 100% Complete!")
        return
    
    data = []
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
    
    # Progress bar for remaining
    remaining = positions[start_idx:]
    
    with tqdm(total=len(remaining), initial=0, desc="Scraping", ncols=80) as pbar:
        for i, pos_id in enumerate(remaining):
            url = f"{BASE_URL}/admin/fulfillment-hubs/positions/{pos_id}"
            headers = {
                "accept": "application/json",
                "x-user-key": current_user_key,
                "x-mobile-secret": MOBILE_SECRET
            }
            
            try:
                resp = session.get(url, headers=headers, timeout=20)
                
                if resp.status_code in [401, 429]:
                    if resp.status_code == 401:
                        get_auth_key()
                    time.sleep(10)
                    pbar.update(0)
                    continue
                
                resp.raise_for_status()
                item = resp.json()
                item["position_id"] = pos_id
                data.append(item)
                
            except:
                pass  # Skip errors
            
            # Save every 10
            if (i + 1) % 10 == 0 or i == len(remaining) - 1:
                save_json(data, DATA_FILE)
                save_progress(start_idx + i + 1, len(data))
            
            pbar.update(1)
            pbar.set_postfix({"Saved": f"{len(data)}", "Rate": f"{1/(DELAY+0.1):.1f}/min"})
            time.sleep(DELAY)
    
    print(f"\n🎉 Complete! {DATA_FILE}: {len(data)} positions")
    try:
        os.remove(PROGRESS_FILE)
    except:
        pass

if __name__ == "__main__":
    main()
