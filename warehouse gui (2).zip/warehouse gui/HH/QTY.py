import json
from collections import Counter, defaultdict


def analyze_warehouse_data(filename='hub_1_positions_full.json'):
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"❌ File '{filename}' not found!")
        return
    except json.JSONDecodeError as e:
        print(f"❌ Invalid JSON: {e}")
        return

    hubs = data if isinstance(data, list) else data.get('hubs', [])
    print(f"✅ Loaded {len(hubs)} hubs\n")

    # Pre-calculate detailed stats
    stats = {
        'shelf': Counter(),
        'priority': Counter(),
        'status': {'locked': 0, 'scrap': 0, 'pallet': 0},
        'stock': {'empty': [], 'stock': [], 'zero': []},  # no mixed used
        'warehouse': Counter()
    }

    for hub in hubs:
        # Shelf
        shelf = hub.get('shelf')
        if shelf is not None:
            stats['shelf'][shelf] += 1

        # Priority
        priority = hub.get('priority')
        if priority is not None:
            stats['priority'][priority] += 1

        # Status
        stats['status']['locked'] += hub.get('is_locked', False)
        stats['status']['scrap'] += hub.get('is_scrap', 0)
        stats['status']['pallet'] += hub.get('is_pallet', 0)

        # Stock analysis
        products = hub.get('in_stock', [])
        quantities = [p.get('quantity', 0) for p in products]
        has_positive = any(q > 0 for q in quantities)
        all_zero = all(q == 0 for q in quantities)

        if not products:
            stats['stock']['empty'].append(hub)
        elif all_zero:
            stats['stock']['zero'].append(hub)
        else:
            stats['stock']['stock'].append(hub)

        # Warehouse counts (by product)
        for product in products:
            stats['warehouse'][product.get('warehouse_name', 'Unknown')] += 1

    print_stats(stats)
    interactive_menu(stats, hubs)


def print_stats(stats):
    print("=== WAREHOUSE STATISTICS ===\n")

    # 1. Shelves
    print("📦 1. HUBS BY SHELF:")
    for i, (shelf, count) in enumerate(sorted(stats['shelf'].items()), 1):
        print(f"   {i}. Shelf {shelf}: {count} hubs")

    print("\n" + "=" * 60)

    # 2. Names (top 1000 hubs with/without stock)
    print("📍 2. HUBS BY LOCATION (Top 1000):")
    all_hubs = (
        stats['stock']['empty'] +
        stats['stock']['stock'] +
        stats['stock']['zero']
    )
    name_stats = Counter(hub.get('name', 'Unknown') for hub in all_hubs)
    for i, (name, count) in enumerate(name_stats.most_common(1000), 1):
        print(f"   {i}. {name}: {count}")

    print("\n" + "=" * 60)

    # 3. Status
    print("🔒 3. STATUS SUMMARY:")
    print(f"   🔒 Locked: {stats['status']['locked']}")
    print(f"   🗑️  Scrap: {stats['status']['scrap']}")
    print(f"   📦 Pallet: {stats['status']['pallet']}")

    print("\n" + "=" * 60)

    # 4. Priority + mixed stock stats
    print("🎯 4. HUBS BY PRIORITY & STOCK STATUS:")
    for priority in sorted(stats['priority']):
        prio_hubs = [h for h in all_hubs if h.get('priority') == priority]

        prio_zero = len([h for h in prio_hubs if h in stats['stock']['zero']])
        prio_stock = len([h for h in prio_hubs if h in stats['stock']['stock']])
        prio_empty = len(prio_hubs) - prio_zero - prio_stock

        status = "🟢" if priority == 1 else "🟡" if priority == 2 else "🔴"
        print(f"   {status} Priority {priority}: {len(prio_hubs)} total")
        print(f"     - ✅ Stock: {prio_stock}")
        print(f"     - ❌ Zero qty only: {prio_zero}")
        print(f"     - ⭕ Empty: {prio_empty}")

    print("\n" + "=" * 60)

    # 5. Stock summary
    print("📊 5. STOCK SUMMARY:")
    total = len(all_hubs)
    print(f"   Total hubs: {total}")
    print(f"   ✅ Hubs with stock: {len(stats['stock']['stock'])}")
    print(f"   ❌ Hubs with only zero qty: {len(stats['stock']['zero'])}")
    print(f"   ⭕ Empty hubs: {len(stats['stock']['empty'])}")

    print("\n🏭 6. TOP 5000 WAREHOUSES:")
    for i, (wh, count) in enumerate(stats['warehouse'].most_common(5000), 1):
        print(f"   {i}. {wh}: {count} products")


def interactive_menu(stats, hubs):
    while True:
        print("\n" + "=" * 60)
        print("🔍 SELECT CATEGORY TO EXPLORE:")
        print("1. Shelves    2. Locations   3. Priority/Stock details")
        print("4. Stock hubs 5. Zero qty hubs  6. Products by warehouse")
        print("7. Main stats (warehouses, SKUs, hubs)")
        print("8. Scrap hubs")
        print("0. Exit")
        choice = input("\nEnter number (0-7): ").strip()

        if choice == '0':
            print("👋 Goodbye!")
            break
        elif choice == '1':
            show_shelf_details(stats)
        elif choice == '2':
            show_locations(stats)
        elif choice == '3':
            show_priority_details(stats)
        elif choice == '4':
            show_category_details(stats['stock']['stock'], "Hubs with stock")
        elif choice == '5':
            show_category_details(stats['stock']['zero'], "Hubs with only zero qty")
        elif choice == '6':
            show_products_by_warehouse(stats, hubs)
        elif choice == '7':
            show_main_stats(stats, hubs)
        elif choice == '8':
            show_scrap_hubs(stats, hubs)
        else:
            print("❌ Invalid choice!")


def show_shelf_details(stats):
    shelf_list = sorted(stats['shelf'].items())
    print("\n📦 SHELF DETAILS (enter shelf number):")
    for i, (shelf, count) in enumerate(shelf_list, 1):
        print(f"{i}. Shelf {shelf}: {count} hubs")

    try:
        idx = int(input("Select shelf number: ")) - 1
        shelf_num = shelf_list[idx][0]
        shelf_hubs = [h for h in (stats['stock']['stock'] + stats['stock']['zero'])
                      if h.get('shelf') == shelf_num]
        show_category_details(shelf_hubs, f"Shelf {shelf_num} hubs")
    except (ValueError, IndexError, Exception):
        print("❌ Invalid selection")


def show_scrap_hubs(stats, hubs):
    scrap_hubs = [h for h in hubs if h.get('is_scrap') == 1]

    print(f"\n🗑️ 8. SCRAP HUBS: {len(scrap_hubs)} hubs")

    if not scrap_hubs:
        return

    # Optional: show some extra stats
    by_priority = defaultdict(list)
    for hub in scrap_hubs:
        prio = hub.get('priority')
        by_priority[prio].append(hub)

    print("\nBy priority:")
    for prio in sorted(by_priority.keys()):
        c = len(by_priority[prio])
        print(f"   Priority {prio}: {c} scrap hubs")

    print("\nShow details:")
    print("1. All scrap hubs")
    print("2. Scrap hubs by priority")
    sub_choice = input("Choose (1/2, 0 to cancel): ").strip()

    if sub_choice == '0':
        return
    elif sub_choice == '1':
        show_category_details(scrap_hubs, "All scrap hubs")
    elif sub_choice == '2':
        prio_str = input("Enter priority (1/2/3, 0 to cancel): ").strip()
        if prio_str == '0':
            return
        try:
            prio = int(prio_str)
            prio_hubs = [h for h in scrap_hubs if h.get('priority') == prio]
            show_category_details(prio_hubs, f"Scrap hubs – Priority {prio}")
        except ValueError:
            print("❌ Invalid priority.")
    else:
        print("❌ Invalid choice.")
        
def show_category_details(hubs_list, title):
    if not hubs_list:
        print("No hubs found")
        return

    print(f"\n{title} ({len(hubs_list)} hubs):")
    for i, hub in enumerate(hubs_list, 1):
        name = hub.get('name', 'Unknown')
        prio = hub.get('priority', '?')
        shelf = hub.get('shelf', '?')
        in_stock = hub.get('in_stock', [])
        products = len(in_stock)
        print(f"{i}. {name} (P{prio}, S{shelf}) - {products} products")


def show_priority_details(stats):
    print("\n🎯 PRIORITY DETAILS:")

    # Build maps: priority → zero‑qty hubs and non‑zero‑qty hubs
    zero_by_prio = defaultdict(list)   # prio → zero‑qty hubs
    non_zero_by_prio = defaultdict(list)  # prio → non‑zero‑qty hubs

    all_hubs = (
        stats['stock']['empty'] +
        stats['stock']['stock'] +
        stats['stock']['zero']
    )

    for hub in all_hubs:
        prio = hub.get('priority')
        if prio is None:
            continue

        # Does this hub have any positive‑qty product?
        has_positive = any(
            p.get('quantity', 0) > 0
            for p in hub.get('in_stock', [])
        )

        if has_positive:
            non_zero_by_prio[prio].append(hub)
        else:
            zero_by_prio[prio].append(hub)

    # Show both zero‑qty and non‑zero‑qty for each priority
    for priority in sorted(zero_by_prio.keys() | non_zero_by_prio.keys()):
        z = len(zero_by_prio[priority])
        nz = len(non_zero_by_prio[priority])
        print(f"Priority {priority} zero‑qty hubs: {z}")
        print(f"Priority {priority} non‑zero‑qty hubs: {nz}")

    # Optional: drill into one priority
    print("\n💡 Show details for priority (0 to cancel):")
    choice = input("Priority (1/2/3): ").strip()
    if choice == '0':
        return

    try:
        prio = int(choice)
        if prio not in [1, 2, 3]:
            print("❌ Priority must be 1, 2, or 3.")
            return

        print(f"\n🎯 PRIORITY {prio} HUBS:")
        print("1. Zero‑qty hubs")
        print("2. Non‑zero‑qty hubs")
        sub_choice = input("Choose (1/2): ").strip()

        if sub_choice == '1':
            hubs_list = zero_by_prio.get(prio, [])
            show_category_details(hubs_list, f"Priority {prio} – zero‑qty hubs")
        elif sub_choice == '2':
            hubs_list = non_zero_by_prio.get(prio, [])
            show_category_details(hubs_list, f"Priority {prio} – non‑zero‑qty hubs")
        else:
            print("❌ Invalid choice.")

    except ValueError:
        print("❌ Invalid priority.")


def show_locations(stats):
    # zero‑qty hubs only
    all_zero = stats['stock']['zero']
    name_stats = Counter(hub.get('name', 'Unknown') for hub in all_zero)
    print("\n📍 Top 5000 zero‑stock locations:")
    for i, (name, count) in enumerate(name_stats.most_common(5000), 1):
        print(f"{i}. {name}: {count}")


def show_products_by_warehouse(stats, hubs):
    # warehouse_name → list of (hub, product, qty, sku, name)
    warehouses = defaultdict(list)

    for hub in hubs:
        for p in hub.get('in_stock', []):
            wh_name = p.get('warehouse_name', 'Unknown')
            qty = p.get('quantity', 0)
            warehouses[wh_name].append({
                'hub_name': hub.get('name', 'Unknown'),
                'sku': p.get('sku', 'N/A'),
                'name': p.get('name', 'N/A'),
                'quantity': qty,
            })

    if not warehouses:
        print("No products found.")
        return

    print("\n🏭 WAREHOUSES (choose warehouse index):")
    wh_list = sorted(warehouses.keys())
    for i, wh in enumerate(wh_list, 1):
        print(f"{i}. {wh} ({len(warehouses[wh])} products)")

    try:
        idx = int(input("Enter warehouse number (0 to cancel): ")) - 1
        if idx == -1:
            return
        wh_name = wh_list[idx]
        products = warehouses[wh_name]

        print(f"\n📦 PRODUCTS IN WAREHOUSE: {wh_name} ({len(products)} items):")
        for i, p in enumerate(products, 1):
            print(f"{i}. [{p['sku']}] {p['name']} – Qty: {p['quantity']} (hub: {p['hub_name']})")
    except (ValueError, IndexError, Exception):
        print("❌ Invalid warehouse number.")


def show_main_stats(stats, hubs):
    # Build flat product list: (warehouse, sku, qty, hub)
    products = []   # list of dict: {warehouse, sku, qty, hub_name}

    for hub in hubs:
        hub_name = hub.get('name', 'Unknown')
        for p in hub.get('in_stock', []):
            wh = p.get('warehouse_name', 'Unknown')
            sku = p.get('sku', 'N/A')
            qty = p.get('quantity', 0)
            products.append({
                'warehouse': wh,
                'sku': sku,
                'quantity': qty,
                'hub_name': hub_name
            })

    # 1. Count warehouses
    warehouses = {p['warehouse'] for p in products}
    warehouses_list = sorted(warehouses)

    # 2. Split SKUs by quantity
    skus_pos = []  # SKUs with qty > 0
    skus_zero = [] # SKUs with qty == 0

    for p in products:
        key = (p['warehouse'], p['sku'])
        if p['quantity'] > 0:
            if key not in skus_pos:
                skus_pos.append(key)
        else:
            if key not in skus_zero:
                skus_zero.append(key)

    # 3. Show summary
    print("\n📊 7. MAIN STATS:")
    print(f"   🏭 Total warehouses: {len(warehouses)}")
    print(f"   ✅ SKU count (quantity > 0): {len(skus_pos)}")
    print(f"   ❌ SKU count (quantity = 0): {len(skus_zero)}")
    print("\n" + "=" * 60)

    # 4. Ask user what to explore
    print("💡 Explore:")
    print("   1. Hubs with positive‑qty SKUs")
    print("   2. Hubs with zero‑qty SKUs")
    print("   3. Hubs per warehouse")
    print("   0. Back")
    choice = input("\nChoose (0–3): ").strip()

    if choice == '0':
        return

    # --- 7.1 Show hubs with positive‑qty SKUs ---
    if choice == '1':
        print("\n📈 HUBS WITH POSITIVE‑QUANTITY SKUs:")
        listings = [
            f"   {i}. {p['hub_name']} – {p['warehouse']} | {p['sku']} (Qty: {p['quantity']})"
            for i, p in enumerate(products, 1) if p['quantity'] > 0
        ]
        if not listings:
            print("   No products with positive quantity.")
            return
        for line in listings:
            print(line)

    # --- 7.2 Show hubs with zero‑qty SKUs ---
    elif choice == '2':
        print("\n📉 HUBS WITH ZERO‑QUANTITY SKUs:")
        listings = [
            f"   {i}. {p['hub_name']} – {p['warehouse']} | {p['sku']} (Qty: {p['quantity']})"
            for i, p in enumerate(products, 1) if p['quantity'] == 0
        ]
        if not listings:
            print("   No products with zero quantity.")
            return
        for line in listings:
            print(line)

    # --- 7.3 Show hubs per warehouse ---
    elif choice == '3':
        wh_map = defaultdict(list)  # warehouse → list of (hub_name, sku, qty)
        for p in products:
            wh_map[p['warehouse']].append(p)

        print("\n🏭 HUBS PER WAREHOUSE:")
        wh_list = sorted(wh_map.keys())
        for i, wh in enumerate(wh_list, 1):
            print(f"{i}. {wh} – {len(wh_map[wh])} SKUs")

        try:
            idx = int(input("Select warehouse (0 to cancel): ")) - 1
            if idx == -1:
                return
            selected_wh = wh_list[idx]
            items = wh_map[selected_wh]
            print(f"\n📦 PRODUCTS IN WAREHOUSE '{selected_wh}':")
            for i, p in enumerate(items, 1):
                print(f"{i}. Hub: {p['hub_name']} | {p['sku']} – Qty: {p['quantity']}")
        except (ValueError, IndexError):
            print("❌ Invalid warehouse number.")
    else:
        print("❌ Invalid choice.")


# Run
if __name__ == "__main__":
    analyze_warehouse_data('hub_1_positions_full.json')
